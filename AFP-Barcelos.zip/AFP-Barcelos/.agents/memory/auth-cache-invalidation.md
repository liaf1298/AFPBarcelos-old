---
name: Auth cache invalidation
description: Regra para terminar sessão corretamente em interfaces React Query.
---

Ao terminar sessão, remover a query de identidade autenticada em vez de apenas atribuir `undefined` ao seu conteúdo.

**Why:** Uma atualização com `undefined` pode deixar a query anterior disponível para a homepage, fazendo a aplicação continuar a renderizar o painel autenticado depois do logout.

**How to apply:** Após o logout confirmado, remover a query de sessão, invalidar apenas os dados públicos necessários e navegar para a rota inicial.