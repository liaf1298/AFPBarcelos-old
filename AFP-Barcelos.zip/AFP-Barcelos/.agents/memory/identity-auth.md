---
name: Identity provider authentication
description: Durable rules for the CMD and Citizen Card authentication flows.
---

The official CMD and Citizen Card providers must be configured through environment variables, never through credentials committed to source. Both flows use authorization-code OAuth/OIDC with PKCE, a signed short-lived server cookie for state, and a server-side user-info request.

**Why:** Provider credentials and endpoints differ between AFP environments, while the callback must remain protected against CSRF, replay, and a successful authentication being attached to the wrong player.

**How to apply:** Keep provider-specific settings under `AFP_CMD_*` and `AFP_CITIZEN_CARD_*`; require an identity claim matching the stored player identifier before setting `authStatus` to `verified`.