import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  ArrowRight,
  BadgeCheck,
  Bell,
  Building2,
  Check,
  ChevronRight,
  CircleDot,
  CircleAlert,
  CircleCheck,
  ClipboardList,
  CreditCard,
  FileCheck2,
  FileText,
  Eye,
  EyeOff,
  Flag,
  FolderOpen,
  LayoutDashboard,
  KeyRound,
  Landmark,
  LockKeyhole,
  LogOut,
  Mail,
  Menu,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Trophy,
  UserRound,
  Users,
  UserRoundCheck,
  X,
} from 'lucide-react';
import {
  AfpRole,
  AfpPlayerAuthMethod,
  type AfpAuthSession,
  getAfpGetAuthSummaryQueryKey,
  getAfpGetClubDashboardQueryKey,
  getAfpGetCurrentUserQueryKey,
  getAfpGetLoginOptionsQueryKey,
  getAfpGetPlayerAuthOptionsQueryKey,
  getAfpListClubDocumentsQueryKey,
  getAfpListClubPlayersQueryKey,
  getAfpListClubRegistrationsQueryKey,
  getAfpListClubTeamsQueryKey,
  getAfpListBoardRegistrationsQueryKey,
  getAfpListBoardRegistrationDocumentsQueryKey,
  getAfpListClubRegistrationDocumentsQueryKey,
  getHealthCheckQueryKey,
  useAfpGetAuthSummary,
  useAfpGetClubDashboard,
  useAfpGetCurrentUser,
  useAfpGetLoginOptions,
  useAfpGetPlayerAuthOptions,
  useAfpListClubDocuments,
  useAfpListClubPlayers,
  useAfpListClubRegistrations,
  useAfpListClubTeams,
  useAfpCreateClubDocument,
  useAfpCreateClubPlayer,
  useAfpCreateClubRegistration,
  useAfpCreateClubTeam,
  useAfpRequestRegistrationDocumentUploadUrl,
  useAfpCreateClubRegistrationDocument,
  useAfpListClubRegistrationDocuments,
  useAfpListBoardRegistrations,
  useAfpListBoardRegistrationDocuments,
  useAfpReviewRegistrationDocument,
  useAfpLogin,
  useAfpRegister,
  useAfpLogout,
  useAfpStartPlayerAuth,
  useHealthCheck,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';

const queryClient = new QueryClient();

type AfpRoleValue = (typeof AfpRole)[keyof typeof AfpRole];

const roleVisuals: Record<AfpRoleValue, {
  icon: typeof Trophy;
  accent: string;
  short: string;
}> = {
  club: { icon: Building2, accent: 'bg-[#e6eff0] text-[#17616a]', short: 'Clubes' },
  referee: { icon: CircleDot, accent: 'bg-[#f5edcb] text-[#8b6a08]', short: 'Arbitragem' },
  observer: { icon: Eye, accent: 'bg-[#eee7f1] text-[#6a4b79]', short: 'Observação' },
  board: { icon: Landmark, accent: 'bg-[#e7eaf0] text-[#3b4966]', short: 'Direção' },
};

const roleDashboardPaths: Record<AfpRoleValue, string> = {
  club: '/club/dashboard',
  referee: '/referee/dashboard',
  observer: '/observer/dashboard',
  board: '/board/dashboard',
};

const roleDashboardContent: Record<AfpRoleValue, {
  area: string;
  eyebrow: string;
  title: string;
  description: string;
  modules: { label: string; text: string; icon: typeof Trophy }[];
}> = {
  club: {
    area: 'Área de clube',
    eyebrow: 'Painel do clube',
    title: 'Operação do seu clube',
    description: 'Consulte jogadores, equipas, documentos e inscrições num só espaço.',
    modules: [
      { label: 'Jogadores e equipas', text: 'Gestão dos seus plantéis', icon: Users },
      { label: 'Documentos', text: 'Validades e pendências', icon: FileText },
      { label: 'Inscrições', text: 'Competições em acompanhamento', icon: ClipboardList },
    ],
  },
  referee: {
    area: 'Área de arbitragem',
    eyebrow: 'Painel do árbitro',
    title: 'A sua área de arbitragem',
    description: 'O ponto de entrada para jogos atribuídos, disponibilidade e relatórios.',
    modules: [
      { label: 'Agenda de jogos', text: 'Consulte as próximas nomeações', icon: Trophy },
      { label: 'Disponibilidade', text: 'Mantenha o seu calendário atualizado', icon: Check },
      { label: 'Relatórios', text: 'Acompanhe os relatórios submetidos', icon: FileCheck2 },
    ],
  },
  observer: {
    area: 'Área de observação',
    eyebrow: 'Painel do observador',
    title: 'A sua área de observação',
    description: 'Organize observações, jogos acompanhados e relatórios técnicos.',
    modules: [
      { label: 'Observações', text: 'Próximos trabalhos atribuídos', icon: Eye },
      { label: 'Equipas e árbitros', text: 'Acompanhe os seus processos', icon: Users },
      { label: 'Relatórios técnicos', text: 'Registe e consulte avaliações', icon: FileText },
    ],
  },
  board: {
    area: 'Área de direção',
    eyebrow: 'Painel da direção',
    title: 'Gestão da AFP Barcelos',
    description: 'Acompanhe a atividade dos clubes, competições e decisões da associação.',
    modules: [
      { label: 'Clubes associados', text: 'Visão sobre a atividade dos clubes', icon: Building2 },
      { label: 'Competições', text: 'Calendário e inscrições em curso', icon: Trophy },
      { label: 'Aprovações', text: 'Itens que aguardam decisão', icon: ClipboardList },
    ],
  },
};

function getErrorMessage(error: unknown, fallback = 'Não foi possível concluir o pedido.') {
  if (!error) return fallback;
  if (typeof error === 'string') return error;
  if (typeof error === 'object') {
    const candidate = error as { message?: string; data?: { error?: string }; response?: { data?: { error?: string } } };
    return candidate.data?.error ?? candidate.response?.data?.error ?? candidate.message ?? fallback;
  }
  return fallback;
}

function BrandMark({ inverse = false }: { inverse?: boolean }) {
  return (
    <div className="flex items-center gap-3" data-testid="brand-afp-barcelos">
      <div className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-[14px] border ${inverse ? 'border-[#f4d15f]/40 bg-[#f4d15f] text-[#1f2b43]' : 'border-[#263451]/20 bg-[#263451] text-[#f4d15f]'}`}>
        <span className="absolute -top-1.5 left-1/2 h-2.5 w-2.5 -translate-x-1/2 rounded-full bg-current" />
        <span className="text-[19px] font-extrabold tracking-[-.12em]">AF</span>
      </div>
      <div className="leading-none">
        <p className={`font-['Space_Grotesk'] text-[16px] font-bold tracking-tight ${inverse ? 'text-[#fbf4e3]' : 'text-[#263451]'}`}>AFP Barcelos</p>
        <p className={`mt-1 font-mono text-[9px] font-medium uppercase tracking-[.22em] ${inverse ? 'text-[#d6d6c8]' : 'text-[#667085]'}`}>Portal de acesso</p>
      </div>
    </div>
  );
}

function StatusPill({ healthy, loading }: { healthy: boolean; loading?: boolean }) {
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-[#d9ddcf] bg-[#f9faf4] px-3 py-1.5 text-[11px] font-semibold text-[#53604c]" data-testid="status-api">
      <span className={`h-1.5 w-1.5 rounded-full ${loading ? 'animate-pulse bg-[#b4a763]' : healthy ? 'bg-[#3c8b65]' : 'bg-[#b25145]'}`} />
      {loading ? 'A verificar ligação' : healthy ? 'Serviços operacionais' : 'Serviço indisponível'}
    </div>
  );
}

function LoadingPanel({ label = 'A preparar o acesso' }: { label?: string }) {
  return (
    <div className="space-y-4" aria-live="polite" data-testid="loading-panel">
      <div className="h-7 w-3/5 animate-pulse rounded-md bg-[#e7e4d9]" />
      <div className="h-4 w-4/5 animate-pulse rounded-md bg-[#eeece4]" />
      <div className="mt-8 space-y-3">
        <div className="h-16 animate-pulse rounded-2xl bg-[#eeece4]" />
        <div className="h-16 animate-pulse rounded-2xl bg-[#eeece4]" />
      </div>
      <p className="pt-2 font-mono text-[10px] uppercase tracking-[.16em] text-[#8d9188]">{label}</p>
    </div>
  );
}

function LoginPanel({
  roles,
  selectedRole,
  onRoleChange,
  onSuccess,
}: {
  roles: { role: AfpRoleValue; label: string; description: string }[];
  selectedRole?: AfpRoleValue;
  onRoleChange: (role: AfpRoleValue) => void;
  onSuccess: () => void;
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [localError, setLocalError] = useState('');
  const login = useAfpLogin();
  const queryClient = useQueryClient();

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLocalError('');
    if (!selectedRole) {
      setLocalError('Escolha primeiro o seu perfil de acesso.');
      return;
    }
    if (!email.trim() || !password) {
      setLocalError('Preencha o email e a palavra-passe para continuar.');
      return;
    }
    login.mutate({ data: { email: email.trim(), password, role: selectedRole } }, {
      onSuccess: (session) => {
        queryClient.setQueryData(getAfpGetCurrentUserQueryKey(), session);
        void queryClient.invalidateQueries({ queryKey: getAfpGetAuthSummaryQueryKey() });
        onSuccess();
      },
      onError: (error) => setLocalError(getErrorMessage(error, 'Credenciais inválidas. Confirme o perfil e tente novamente.')),
    });
  };

  return (
    <form className="mt-7" onSubmit={submit} noValidate data-testid="form-afp-login">
      {(localError || login.isError) && (
        <div className="mb-5 flex gap-3 rounded-2xl border border-[#e7c2bd] bg-[#fff4f1] px-4 py-3.5 text-sm text-[#9b443a]" role="alert" data-testid="alert-login-error">
          <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{localError || getErrorMessage(login.error, 'Não foi possível iniciar sessão.')}</span>
        </div>
      )}
      <div className="space-y-2">
        <label className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]" htmlFor="afp-email">Email profissional</label>
        <div className="relative">
          <Mail className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8b928a]" />
          <input id="afp-email" type="email" autoComplete="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="nome@afpbarcelos.pt" className="h-13 w-full rounded-xl border border-[#dcded4] bg-[#fcfcf8] pl-11 pr-4 text-sm text-[#263451] transition-colors placeholder:text-[#a2a69e] hover:border-[#adb6a7] focus:border-[#263451] focus:bg-white" data-testid="input-email" />
        </div>
      </div>
      <div className="mt-5 space-y-2">
        <div className="flex items-center justify-between">
          <label className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]" htmlFor="afp-password">Palavra-passe</label>
          <span className="text-[11px] text-[#9a9b91]">Acesso reservado</span>
        </div>
        <div className="relative">
          <LockKeyhole className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8b928a]" />
          <input id="afp-password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Introduza a sua palavra-passe" className="h-13 w-full rounded-xl border border-[#dcded4] bg-[#fcfcf8] pl-11 pr-12 text-sm text-[#263451] transition-colors placeholder:text-[#a2a69e] hover:border-[#adb6a7] focus:border-[#263451] focus:bg-white" data-testid="input-password" />
          <button type="button" aria-label={showPassword ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe'} onClick={() => setShowPassword((value) => !value)} className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-2 text-[#7d867c] transition-colors hover:bg-[#efeee7] hover:text-[#263451]" data-testid="button-toggle-password">
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>
      <button type="submit" disabled={login.isPending || !selectedRole} className="group mt-7 flex h-13 w-full items-center justify-center gap-3 rounded-xl bg-[#263451] px-5 text-sm font-bold text-[#fbf4e3] transition-all hover:bg-[#334566] active:scale-[.99] disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-submit-login">
        {login.isPending ? 'A validar acesso...' : 'Entrar no portal'}
        {!login.isPending && <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />}
      </button>
      <div className="mt-5 flex items-center justify-center gap-2 text-center">
        <ShieldCheck className="h-3.5 w-3.5 text-[#7b8b76]" />
        <p className="text-[11px] text-[#7a8178]">Ligação protegida · Sessão mantida com segurança</p>
      </div>
    </form>
  );
}

function RegisterPanel({
  roles,
  selectedRole,
  onRoleChange,
  onSuccess,
}: {
  roles: { role: AfpRoleValue; label: string; description: string }[];
  selectedRole?: AfpRoleValue;
  onRoleChange: (role: AfpRoleValue) => void;
  onSuccess: () => void;
}) {
  const [name, setName] = useState('');
  const [affiliation, setAffiliation] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [localError, setLocalError] = useState('');
  const register = useAfpRegister();
  const queryClient = useQueryClient();

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLocalError('');
    if (!selectedRole) {
      setLocalError('Escolha primeiro o seu perfil de acesso.');
      return;
    }
    if (password !== confirmPassword) {
      setLocalError('As palavras-passe não coincidem.');
      return;
    }
    register.mutate({
      data: {
        name: name.trim(),
        email: email.trim(),
        password,
        role: selectedRole,
        affiliation: affiliation.trim(),
      },
    }, {
      onSuccess: (session) => {
        queryClient.setQueryData(getAfpGetCurrentUserQueryKey(), session);
        void queryClient.invalidateQueries({ queryKey: getAfpGetAuthSummaryQueryKey() });
        onSuccess();
      },
      onError: (error) => setLocalError(getErrorMessage(error, 'Não foi possível criar a conta.')),
    });
  };

  return (
    <form className="mt-7" onSubmit={submit} noValidate data-testid="form-afp-register">
      {(localError || register.isError) && (
        <div className="mb-5 flex gap-3 rounded-2xl border border-[#e7c2bd] bg-[#fff4f1] px-4 py-3.5 text-sm text-[#9b443a]" role="alert" data-testid="alert-register-error">
          <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{localError || getErrorMessage(register.error, 'Não foi possível criar a conta.')}</span>
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="space-y-2 sm:col-span-2"><span className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]">Nome completo</span><input required minLength={2} maxLength={120} value={name} onChange={(event) => setName(event.target.value)} placeholder="O seu nome" className="h-12 w-full rounded-xl border border-[#dcded4] bg-[#fcfcf8] px-4 text-sm text-[#263451] transition-colors placeholder:text-[#a2a69e] hover:border-[#adb6a7] focus:border-[#263451] focus:bg-white" data-testid="input-register-name" /></label>
        <label className="space-y-2 sm:col-span-2"><span className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]">Clube ou entidade</span><input required minLength={2} maxLength={120} value={affiliation} onChange={(event) => setAffiliation(event.target.value)} placeholder="Ex.: AFP Barcelos" className="h-12 w-full rounded-xl border border-[#dcded4] bg-[#fcfcf8] px-4 text-sm text-[#263451] transition-colors placeholder:text-[#a2a69e] hover:border-[#adb6a7] focus:border-[#263451] focus:bg-white" data-testid="input-register-affiliation" /></label>
        <label className="space-y-2 sm:col-span-2"><span className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]">Email profissional</span><input required type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="nome@exemplo.pt" className="h-12 w-full rounded-xl border border-[#dcded4] bg-[#fcfcf8] px-4 text-sm text-[#263451] transition-colors placeholder:text-[#a2a69e] hover:border-[#adb6a7] focus:border-[#263451] focus:bg-white" data-testid="input-register-email" /></label>
        <label className="space-y-2"><span className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]">Palavra-passe</span><input required minLength={8} maxLength={128} type="password" autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Mínimo de 8 caracteres" className="h-12 w-full rounded-xl border border-[#dcded4] bg-[#fcfcf8] px-4 text-sm text-[#263451] transition-colors placeholder:text-[#a2a69e] hover:border-[#adb6a7] focus:border-[#263451] focus:bg-white" data-testid="input-register-password" /></label>
        <label className="space-y-2"><span className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]">Confirmar palavra-passe</span><input required minLength={8} maxLength={128} type="password" autoComplete="new-password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} placeholder="Repita a palavra-passe" className="h-12 w-full rounded-xl border border-[#dcded4] bg-[#fcfcf8] px-4 text-sm text-[#263451] transition-colors placeholder:text-[#a2a69e] hover:border-[#adb6a7] focus:border-[#263451] focus:bg-white" data-testid="input-register-confirm-password" /></label>
      </div>
      <button type="submit" disabled={register.isPending || !selectedRole} className="group mt-7 flex h-13 w-full items-center justify-center gap-3 rounded-xl bg-[#263451] px-5 text-sm font-bold text-[#fbf4e3] transition-all hover:bg-[#334566] active:scale-[.99] disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-submit-register">
        {register.isPending ? 'A criar conta...' : 'Criar conta e entrar'}
        {!register.isPending && <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />}
      </button>
      <div className="mt-5 flex items-center justify-center gap-2 text-center"><ShieldCheck className="h-3.5 w-3.5 text-[#7b8b76]" /><p className="text-[11px] text-[#7a8178]">Os seus dados ficam protegidos pela AFP Barcelos</p></div>
    </form>
  );
}

function RolePicker({
  roles,
  selectedRole,
  onRoleChange,
}: {
  roles: { role: AfpRoleValue; label: string; description: string }[];
  selectedRole?: AfpRoleValue;
  onRoleChange: (role: AfpRoleValue) => void;
}) {
  return (
    <div className="space-y-3" data-testid="role-picker">
      {roles.map((option) => {
        const visual = roleVisuals[option.role];
        const Icon = visual?.icon ?? UserRound;
        const isSelected = selectedRole === option.role;
        return (
          <button type="button" key={option.role} onClick={() => onRoleChange(option.role)} className={`group flex w-full items-center gap-4 rounded-2xl border px-4 py-3.5 text-left transition-all ${isSelected ? 'border-[#263451] bg-[#263451] text-[#fbf4e3] shadow-[0_8px_20px_-12px_rgba(38,52,81,.8)]' : 'border-[#e2e2d8] bg-[#fbfbf7] text-[#263451] hover:-translate-y-0.5 hover:border-[#b5bcae] hover:bg-white'}`} aria-pressed={isSelected} data-testid={`button-role-${option.role}`}>
            <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${isSelected ? 'bg-[#f4d15f] text-[#263451]' : visual?.accent ?? 'bg-[#ecece5] text-[#263451]'}`}>
              <Icon className="h-[18px] w-[18px]" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[13px] font-bold">{option.label}</span>
              <span className={`mt-0.5 block truncate text-[11px] ${isSelected ? 'text-[#d6d9d1]' : 'text-[#7d847b]'}`}>{option.description}</span>
            </span>
            <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${isSelected ? 'border-[#f4d15f] bg-[#f4d15f] text-[#263451]' : 'border-[#d3d7cd] text-transparent'}`}><Check className="h-3 w-3" /></span>
          </button>
        );
      })}
    </div>
  );
}

function SummaryRail({ summary, summaryLoading }: { summary?: { totalUsers: number; activeSessions: number; roles: { role: AfpRoleValue; label: string; count: number }[] }; summaryLoading: boolean }) {
  return (
    <aside className="hidden min-h-screen w-[41%] max-w-[560px] flex-col justify-between bg-[#263451] px-10 py-9 text-[#fbf4e3] lg:flex xl:px-14" data-testid="summary-rail">
      <div>
        <BrandMark inverse />
        <div className="mt-[clamp(80px,16vh,160px)] max-w-[430px]">
          <div className="mb-7 flex items-center gap-3 font-mono text-[10px] uppercase tracking-[.2em] text-[#d1bc68]">
            <span className="h-px w-9 bg-[#d1bc68]" /> Desde 1928
          </div>
          <h1 className="font-['Space_Grotesk'] text-[clamp(44px,5vw,70px)] font-semibold leading-[.97] tracking-[-.065em]">O futebol<br /><span className="text-[#f4d15f]">começa aqui.</span></h1>
          <p className="mt-7 max-w-[350px] text-[14px] leading-7 text-[#c7c9c1]">A porta de entrada digital para quem faz viver o futebol distrital em Barcelos.</p>
        </div>
      </div>
      <div className="border-t border-[#526078] pt-7">
        <div className="flex items-end justify-between">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#abb4b5]">Rede AFP Barcelos</p>
            <p className="mt-2 text-sm text-[#f5f2e8]">Uma comunidade, quatro perspetivas.</p>
          </div>
          <div className="flex -space-x-2" aria-label="Perfis da comunidade">
            {['C', 'A', 'O', 'D'].map((letter, index) => <span key={letter} className={`flex h-8 w-8 items-center justify-center rounded-full border-2 border-[#263451] text-[10px] font-bold ${['bg-[#b3d3cf]', 'bg-[#f4d15f]', 'bg-[#cfb8d7]', 'bg-[#aebbd4]'][index]} text-[#263451]`} data-testid={`avatar-profile-${index}`}>{letter}</span>)}
          </div>
        </div>
      </div>
    </aside>
  );
}

function OperationalSummary({ summary, loading, error, onRetry }: { summary?: { totalUsers: number; activeSessions: number; roles: { role: AfpRoleValue; label: string; count: number }[] }; loading: boolean; error: unknown; onRetry: () => void }) {
  const maxCount = useMemo(() => Math.max(...(summary?.roles?.map((role) => role.count) ?? [1]), 1), [summary]);
  return (
    <section className="mt-12 border-t border-[#e1e0d6] pt-7" data-testid="section-operational-summary">
      <div className="flex items-start justify-between gap-5">
        <div>
          <p className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#858b82]">Leitura operacional</p>
          <h2 className="mt-1.5 font-['Space_Grotesk'] text-lg font-semibold tracking-[-.03em] text-[#263451]">A comunidade em movimento</h2>
        </div>
        <Flag className="mt-1 h-5 w-5 text-[#b39c3a]" />
      </div>
      {loading ? (
        <div className="mt-6 grid grid-cols-2 gap-3" aria-live="polite" data-testid="summary-skeleton">
          {[1, 2, 3, 4].map((item) => <div key={item} className="h-20 animate-pulse rounded-xl bg-[#ecebe3]" />)}
        </div>
      ) : error ? (
        <div className="mt-5 flex items-center justify-between gap-3 rounded-xl border border-[#e4d5c9] bg-[#faf3eb] px-4 py-3 text-xs text-[#87644f]" data-testid="summary-error">
          <span>O resumo não está disponível neste momento.</span>
          <button type="button" onClick={onRetry} className="inline-flex items-center gap-1.5 font-bold text-[#263451] hover:underline" data-testid="button-retry-summary"><RefreshCw className="h-3.5 w-3.5" /> Tentar</button>
        </div>
      ) : (
        <>
          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-[#e3e1d8] bg-[#fbfbf7] px-4 py-3.5" data-testid="metric-total-users">
              <Users className="h-4 w-4 text-[#74856f]" />
              <p className="mt-2 font-['Space_Grotesk'] text-2xl font-semibold text-[#263451]">{summary?.totalUsers ?? '—'}</p>
              <p className="text-[10px] uppercase tracking-[.12em] text-[#878d84]">Utilizadores</p>
            </div>
            <div className="rounded-xl border border-[#e3e1d8] bg-[#fbfbf7] px-4 py-3.5" data-testid="metric-active-sessions">
              <CircleCheck className="h-4 w-4 text-[#3c8b65]" />
              <p className="mt-2 font-['Space_Grotesk'] text-2xl font-semibold text-[#263451]">{summary?.activeSessions ?? '—'}</p>
              <p className="text-[10px] uppercase tracking-[.12em] text-[#878d84]">Sessões ativas</p>
            </div>
          </div>
          <div className="mt-5 space-y-3">
            {(summary?.roles ?? []).map((role) => (
              <div key={role.role} className="flex items-center gap-3" data-testid={`summary-role-${role.role}`}>
                <span className="w-[94px] truncate text-[11px] font-semibold text-[#5e685f]">{role.label}</span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#e4e5dc]"><div className="h-full rounded-full bg-[#b19a37] transition-all" style={{ width: `${Math.max(8, (role.count / maxCount) * 100)}%` }} /></div>
                <span className="w-7 text-right font-mono text-[11px] text-[#53604c]">{role.count}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}

type WorkspacePage = 'dashboard' | 'players' | 'teams' | 'documents' | 'registrations' | 'player-auth';

const workspaceNav: { path: WorkspacePage; label: string; hint: string; icon: typeof LayoutDashboard }[] = [
  { path: 'dashboard', label: 'Visão geral', hint: 'Operação do clube', icon: LayoutDashboard },
  { path: 'players', label: 'Jogadores', hint: 'Registo e elegibilidade', icon: Users },
  { path: 'teams', label: 'Equipas', hint: 'Plantéis e épocas', icon: Trophy },
  { path: 'documents', label: 'Documentos', hint: 'Arquivo documental', icon: FolderOpen },
  { path: 'registrations', label: 'Inscrições', hint: 'Competições AFP', icon: ClipboardList },
  { path: 'player-auth', label: 'Autenticação', hint: 'CMD e Cartão de Cidadão', icon: UserRoundCheck },
];

function formatDate(value?: string | null) {
  if (!value) return '—';
  return new Date(value).toLocaleDateString('pt-PT', { day: '2-digit', month: 'short', year: 'numeric' });
}

function ShellButton({ children, onClick, variant = 'primary', type = 'button', disabled = false, testId }: { children: ReactNode; onClick?: () => void; variant?: 'primary' | 'quiet' | 'outline'; type?: 'button' | 'submit'; disabled?: boolean; testId?: string }) {
  const styles = variant === 'primary'
    ? 'bg-[#273a60] text-[#fff7d8] hover:bg-[#334b78] shadow-[0_10px_22px_-16px_rgba(39,58,96,.9)]'
    : variant === 'outline'
      ? 'border border-[#d7dacd] bg-[#fbfcf6] text-[#33415e] hover:border-[#aeb8a7] hover:bg-white'
      : 'bg-transparent text-[#677163] hover:bg-[#eef1e8] hover:text-[#273a60]';
  return <button type={type} onClick={onClick} disabled={disabled} className={`inline-flex min-h-10 items-center justify-center gap-2 rounded-xl px-4 text-xs font-bold transition-all active:scale-[.985] disabled:cursor-not-allowed disabled:opacity-50 ${styles}`} data-testid={testId}>{children}</button>;
}

function StatusTag({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'green' | 'amber' | 'blue' | 'red' | 'neutral' }) {
  const styles = { green: 'bg-[#e7f2ea] text-[#327051]', amber: 'bg-[#f8f0d6] text-[#8a6b16]', blue: 'bg-[#e8eef8] text-[#425e8d]', red: 'bg-[#f9e8e5] text-[#a3493d]', neutral: 'bg-[#edf0eb] text-[#687368]' };
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.08em] ${styles[tone]}`}><span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />{children}</span>;
}

function PageSkeleton() {
  return <div className="space-y-5" aria-live="polite" data-testid="workspace-loading"><div className="h-8 w-52 animate-pulse rounded-lg bg-[#e5e9df]" /><div className="h-4 w-80 max-w-full animate-pulse rounded bg-[#eceee8]" /><div className="grid gap-4 md:grid-cols-3"><div className="h-28 animate-pulse rounded-2xl bg-[#e5e9df]" /><div className="h-28 animate-pulse rounded-2xl bg-[#e5e9df]" /><div className="h-28 animate-pulse rounded-2xl bg-[#e5e9df]" /></div><div className="h-72 animate-pulse rounded-2xl bg-[#eceee8]" /></div>;
}

function WorkspaceHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <header className="mb-7 flex flex-col gap-5 border-b border-[#dde2d7] pb-7 sm:flex-row sm:items-end sm:justify-between"><div><p className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#9a7513]">{eyebrow}</p><h1 className="mt-2 font-['Space_Grotesk'] text-[clamp(30px,4vw,46px)] font-semibold leading-none tracking-[-.055em] text-[#273a60]">{title}</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-[#717b70]">{description}</p></div>{action}</header>;
}

function EmptyState({ icon: Icon, title, text, action }: { icon: typeof FolderOpen; title: string; text: string; action?: ReactNode }) {
  return <div className="flex min-h-48 flex-col items-center justify-center rounded-2xl border border-dashed border-[#ccd4c8] bg-[#f9fbf5] px-6 py-10 text-center" data-testid="empty-state"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eef2e7] text-[#687b68]"><Icon className="h-5 w-5" /></span><h3 className="mt-4 font-['Space_Grotesk'] text-lg font-semibold text-[#33415e]">{title}</h3><p className="mt-1 max-w-sm text-xs leading-5 text-[#7b857a]">{text}</p>{action && <div className="mt-4">{action}</div>}</div>;
}

function WorkspaceSidebar({ session, active, onLogout, mobileOpen, onClose }: { session: AfpAuthSession; active: WorkspacePage; onLogout: () => void; mobileOpen: boolean; onClose: () => void }) {
  const logout = useAfpLogout();
  const queryClient = useQueryClient();
  const doLogout = () => logout.mutate(undefined, { onSuccess: () => { queryClient.removeQueries({ queryKey: getAfpGetCurrentUserQueryKey() }); onLogout(); } });
  return <aside className={`fixed inset-y-0 left-0 z-30 flex w-[286px] flex-col bg-[#273a60] px-5 py-6 text-[#f8f2dc] transition-transform duration-300 lg:static lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`} data-testid="club-sidebar">
    <div className="flex items-center justify-between"><BrandMark inverse /><button type="button" onClick={onClose} className="rounded-lg p-2 text-[#c5cfcc] hover:bg-[#344d78] lg:hidden" data-testid="button-close-sidebar"><X className="h-4 w-4" /></button></div>
    <div className="mt-9 rounded-2xl border border-[#526889] bg-[#203252] p-3.5"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-[#b8c4c4]">Clube autenticado</p><p className="mt-2 truncate text-sm font-bold text-[#fff7d8]" data-testid="text-club-name">{session.user.affiliation}</p><div className="mt-3 flex items-center gap-2 text-[10px] text-[#b5c1be]"><span className="h-1.5 w-1.5 rounded-full bg-[#e8c947]" /> Época em curso · 2024/25</div></div>
    <nav className="mt-8 flex-1 space-y-1.5" aria-label="Navegação do clube">{workspaceNav.map(({ path, label, hint, icon: Icon }) => <Link key={path} href={`/club/${path}`} onClick={onClose} className={`group flex items-center gap-3 rounded-xl px-3 py-3 transition-colors ${active === path ? 'bg-[#e7c84d] text-[#263858]' : 'text-[#c7d0cc] hover:bg-[#344d78] hover:text-[#fff7d8]'}`} data-testid={`link-club-${path}`}><span className={`flex h-8 w-8 items-center justify-center rounded-lg ${active === path ? 'bg-[#f6e28b]' : 'bg-[#30466d] group-hover:bg-[#41577e]'}`}><Icon className="h-4 w-4" /></span><span className="min-w-0"><span className="block text-xs font-bold">{label}</span><span className={`mt-0.5 block truncate text-[10px] ${active === path ? 'text-[#56603c]' : 'text-[#9fada9]'}`}>{hint}</span></span>{active === path && <ChevronRight className="ml-auto h-4 w-4" />}</Link>)}</nav>
    <div className="border-t border-[#526889] pt-5"><div className="flex items-center gap-3 px-2"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e7c84d] text-sm font-extrabold text-[#273a60]">{session.user.name.charAt(0)}</span><div className="min-w-0"><p className="truncate text-xs font-bold text-[#fff7d8]">{session.user.name}</p><p className="mt-0.5 truncate text-[10px] text-[#aebbb7]">{session.user.email}</p></div></div><button type="button" onClick={doLogout} disabled={logout.isPending} className="mt-4 flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold text-[#bdc9c5] hover:bg-[#344d78] hover:text-[#fff7d8]" data-testid="button-workspace-logout"><LogOut className="h-4 w-4" />{logout.isPending ? 'A terminar...' : 'Terminar sessão'}</button></div>
  </aside>;
}

function WorkspaceShell({ session, children, active }: { session: AfpAuthSession; children: ReactNode; active: WorkspacePage }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [, setLocation] = useLocation();
  return <div className="afp-noise min-h-[100dvh] bg-[#f2f5ee] text-[#273a60]"><div className="flex min-h-[100dvh]"><WorkspaceSidebar session={session} active={active} onLogout={() => setLocation('/')} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} /><div className="min-w-0 flex-1"><header className="sticky top-0 z-20 flex h-[76px] items-center justify-between border-b border-[#dde2d7]/90 bg-[#f7f9f3]/90 px-5 backdrop-blur-md sm:px-8 lg:px-10"><div className="flex items-center gap-3"><button type="button" onClick={() => setMobileOpen(true)} className="rounded-xl border border-[#d9dfd5] bg-[#fbfcf7] p-2.5 text-[#33415e] lg:hidden" data-testid="button-open-sidebar"><Menu className="h-4 w-4" /></button><div className="hidden sm:block"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-[#8a9589]">AFP Barcelos / Área de clube</p><p className="mt-1 text-xs font-semibold text-[#52634e]">Operação segura e centralizada</p></div></div><div className="relative flex items-center gap-3"><span className="hidden items-center gap-2 rounded-full border border-[#dbe1d7] bg-[#fbfcf7] px-3 py-2 text-[10px] font-bold text-[#58705d] sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#3c9568]" /> Serviços operacionais</span><button type="button" onClick={() => setNoticeOpen((value) => !value)} className="rounded-xl border border-[#dbe1d7] bg-[#fbfcf7] p-2.5 text-[#718072] hover:text-[#273a60]" data-testid="button-notifications"><Bell className="h-4 w-4" /></button>{noticeOpen && <div className="absolute right-0 top-12 z-30 w-64 rounded-2xl border border-[#dbe1d7] bg-[#fbfcf7] p-4 shadow-[0_18px_40px_-25px_rgba(39,58,96,.8)]" data-testid="notifications-panel"><p className="font-mono text-[9px] uppercase tracking-[.16em] text-[#9a7513]">Notificações</p><p className="mt-3 text-xs font-semibold text-[#52634e]">Sem novas notificações</p><p className="mt-1 text-[11px] leading-5 text-[#899488]">As atualizações do seu clube aparecerão aqui.</p></div>}</div></header><main className="mx-auto max-w-[1440px] px-5 py-8 sm:px-8 sm:py-10 lg:px-10">{children}</main></div></div>{mobileOpen && <button type="button" aria-label="Fechar menu" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-20 bg-[#182844]/35 lg:hidden" data-testid="button-sidebar-overlay" />}</div>;
}

function ErrorState({ onRetry }: { onRetry: () => void }) {
  return <div className="rounded-2xl border border-[#ead5ce] bg-[#fff6f1] p-7" data-testid="workspace-error"><div className="flex items-start gap-3"><CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-[#ad5546]" /><div><h3 className="font-semibold text-[#713f37]">Não foi possível carregar esta área</h3><p className="mt-1 text-sm text-[#89665d]">A ligação ao serviço AFP falhou. Os seus dados permanecem protegidos.</p><ShellButton variant="outline" onClick={onRetry} testId="button-retry-workspace"><RefreshCw className="h-3.5 w-3.5" /> Tentar novamente</ShellButton></div></div></div>;
}

function DashboardPage() {
  const dashboard = useAfpGetClubDashboard({ query: { queryKey: getAfpGetClubDashboardQueryKey(), staleTime: 30000 } });
  if (dashboard.isLoading) return <PageSkeleton />;
  if (dashboard.isError || !dashboard.data) return <ErrorState onRetry={() => void dashboard.refetch()} />;
  const data = dashboard.data;
  const metricCards = [{ label: 'Jogadores registados', value: data.metrics.playerCount, note: `${data.metrics.verifiedPlayers} com identidade verificada`, icon: Users, tone: 'blue' }, { label: 'Equipas ativas', value: data.metrics.teamCount, note: 'Plantéis desta época', icon: Trophy, tone: 'green' }, { label: 'Documentos pendentes', value: data.metrics.pendingDocuments, note: 'A requerer atenção', icon: FileText, tone: 'amber' }, { label: 'Inscrições em fila', value: data.metrics.pendingRegistrations, note: 'Aguardam tratamento AFP', icon: ClipboardList, tone: 'blue' }] as const;
  return <div className="afp-rise" data-testid="club-dashboard"><WorkspaceHeader eyebrow="Painel do clube" title={`Bom dia, ${data.club.name}.`} description="Uma leitura rápida do que precisa de atenção antes da próxima jornada." action={<ShellButton onClick={() => void dashboard.refetch()} testId="button-dashboard-refresh"><RefreshCw className="h-3.5 w-3.5" /> Atualizar</ShellButton>} /><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{metricCards.map(({ label, value, note, icon: Icon, tone }) => <div key={label} className="rounded-2xl border border-[#dde3d8] bg-[#fbfcf7] p-5 shadow-[0_12px_30px_-26px_rgba(39,58,96,.8)]" data-testid={`metric-${label.replaceAll(' ', '-').toLowerCase()}`}><div className="flex items-start justify-between"><span className={`flex h-10 w-10 items-center justify-center rounded-xl ${tone === 'amber' ? 'bg-[#f7efd5] text-[#96731e]' : tone === 'green' ? 'bg-[#e5f1e8] text-[#3f7b5b]' : 'bg-[#e7eef9] text-[#49658e]'}`}><Icon className="h-[18px] w-[18px]" /></span><span className="font-mono text-[10px] text-[#8b9589]">2024/25</span></div><p className="mt-6 font-['Space_Grotesk'] text-4xl font-semibold tracking-[-.06em] text-[#273a60]">{value}</p><p className="mt-1 text-xs font-bold text-[#52634e]">{label}</p><p className="mt-1 text-[11px] text-[#8a9489]">{note}</p></div>)}</div><div className="mt-7 grid gap-5 xl:grid-cols-[1.35fr_.65fr]"><section className="rounded-2xl border border-[#dde3d8] bg-[#fbfcf7] p-6" data-testid="panel-attention"><div className="flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#9a7513]">Próximas ações</p><h2 className="mt-1.5 font-['Space_Grotesk'] text-xl font-semibold tracking-[-.04em]">O que merece a sua atenção</h2></div><SlidersHorizontal className="h-5 w-5 text-[#9b8121]" /></div><div className="mt-6 divide-y divide-[#e8ebe3]">{data.attention.length === 0 ? <EmptyState icon={Check} title="Tudo em dia" text="Não existem pendências operacionais neste momento." /> : data.attention.map((item) => <div key={item.kind} className="flex items-center gap-4 py-4 first:pt-0 last:pb-0"><span className={`flex h-10 w-10 items-center justify-center rounded-xl ${item.tone === 'amber' ? 'bg-[#f7efd5] text-[#96731e]' : item.tone === 'green' ? 'bg-[#e5f1e8] text-[#3f7b5b]' : 'bg-[#e7eef9] text-[#49658e]'}`}><CircleAlert className="h-4 w-4" /></span><div className="min-w-0 flex-1"><p className="text-sm font-bold text-[#33415e]">{item.label}</p><p className="mt-1 text-xs text-[#849084]">Itens que precisam de decisão ou revisão</p></div><span className="font-['Space_Grotesk'] text-2xl font-semibold text-[#273a60]">{item.count}</span><ChevronRight className="h-4 w-4 text-[#a0aa9c]" /></div>)}</div></section><section className="relative overflow-hidden rounded-2xl bg-[#273a60] p-6 text-[#fff7d8]" data-testid="panel-club-context"><div className="absolute -right-16 -top-20 h-52 w-52 rounded-full border-[24px] border-[#e7c84d]/10" /><div className="relative"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#e6ce64]">Clube em foco</p><h2 className="mt-3 max-w-xs font-['Space_Grotesk'] text-3xl font-semibold leading-[1.02] tracking-[-.055em]">{data.club.name}</h2><p className="mt-4 text-sm leading-6 text-[#c8d0cb]">A sua operação está organizada para a época {data.club.season}.</p><div className="mt-9 border-t border-[#526889] pt-4"><p className="text-[10px] uppercase tracking-[.14em] text-[#aebbb7]">Estado de ligação</p><p className="mt-2 flex items-center gap-2 text-sm font-bold"><span className="h-2 w-2 rounded-full bg-[#e7c84d]" /> API AFP operacional</p></div></div></section></div></div>;
}

function FormField({ label, value, onChange, placeholder, type = 'text', required = true, error, testId }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; type?: string; required?: boolean; error?: string; testId: string }) {
  return <label className="block space-y-2"><span className="font-mono text-[10px] font-medium uppercase tracking-[.15em] text-[#667367]">{label}{required && <span className="text-[#a87517]"> *</span>}</span><input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} required={required} className={`h-11 w-full rounded-xl border bg-[#fbfcf7] px-3.5 text-sm text-[#33415e] outline-none transition-colors placeholder:text-[#aab1a8] focus:border-[#7188a8] focus:bg-white ${error ? 'border-[#c66b5d]' : 'border-[#d8dfd4]'}`} data-testid={testId} />{error && <span className="text-[11px] text-[#ad5546]">{error}</span>}</label>;
}

function Modal({ title, description, onClose, children }: { title: string; description: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#182844]/40 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" role="dialog" aria-modal="true" data-testid="modal-form"><div className="max-h-[92dvh] w-full max-w-2xl overflow-y-auto rounded-t-[26px] border border-[#dce3d7] bg-[#f9fbf5] p-6 shadow-[0_30px_80px_-30px_rgba(23,37,63,.55)] sm:rounded-[26px] sm:p-8"><div className="flex items-start justify-between gap-5"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#9a7513]">Novo registo</p><h2 className="mt-2 font-['Space_Grotesk'] text-2xl font-semibold tracking-[-.045em] text-[#273a60]">{title}</h2><p className="mt-2 text-xs leading-5 text-[#7a8679]">{description}</p></div><button type="button" onClick={onClose} className="rounded-xl p-2 text-[#758174] hover:bg-[#eaf0e7] hover:text-[#273a60]" data-testid="button-close-modal"><X className="h-5 w-5" /></button></div><div className="mt-7">{children}</div></div></div>;
}

function PlayersPage() {
  const queryClient = useQueryClient();
  const players = useAfpListClubPlayers({ query: { queryKey: getAfpListClubPlayersQueryKey(), staleTime: 30000 } });
  const teams = useAfpListClubTeams({ query: { queryKey: getAfpListClubTeamsQueryKey(), staleTime: 30000 } });
  const create = useAfpCreateClubPlayer();
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ fullName: '', birthDate: '', nationalId: '', position: '', teamId: '' });
  const [feedback, setFeedback] = useState('');
  const list = useMemo(() => (players.data ?? []).filter((player) => `${player.fullName} ${player.nationalId} ${player.position}`.toLowerCase().includes(search.toLowerCase())), [players.data, search]);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.fullName.trim() || !form.birthDate || !form.nationalId.trim() || !form.position.trim()) return setFeedback('Preencha todos os campos obrigatórios.');
    create.mutate({ data: { fullName: form.fullName.trim(), birthDate: form.birthDate, nationalId: form.nationalId.trim(), position: form.position.trim(), teamId: form.teamId ? Number(form.teamId) : null } }, { onSuccess: () => { setFeedback('Jogador criado com sucesso.'); setForm({ fullName: '', birthDate: '', nationalId: '', position: '', teamId: '' }); void queryClient.invalidateQueries({ queryKey: getAfpListClubPlayersQueryKey() }); void queryClient.invalidateQueries({ queryKey: getAfpGetClubDashboardQueryKey() }); setTimeout(() => { setOpen(false); setFeedback(''); }, 900); }, onError: (error) => setFeedback(getErrorMessage(error, 'Não foi possível criar o jogador.')) });
  };
  return <div data-testid="players-page"><WorkspaceHeader eyebrow="Registo de jogadores" title="Jogadores" description="Consulte a elegibilidade e mantenha o registo do plantel sempre atualizado." action={<ShellButton onClick={() => setOpen(true)} testId="button-create-player"><Plus className="h-4 w-4" /> Novo jogador</ShellButton>} /><div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div className="relative w-full max-w-md"><Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8b978a]" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar por nome, posição ou NIF" className="h-11 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] pl-10 pr-4 text-sm text-[#33415e] outline-none focus:border-[#7188a8]" data-testid="input-search-players" /></div><p className="text-xs text-[#7e8a7d]"><span className="font-bold text-[#33415e]">{list.length}</span> de {players.data?.length ?? 0} jogadores</p></div>{players.isLoading ? <PageSkeleton /> : players.isError ? <ErrorState onRetry={() => void players.refetch()} /> : list.length === 0 ? <EmptyState icon={Users} title={search ? 'Nenhum resultado' : 'Ainda sem jogadores'} text={search ? 'Experimente outro termo de pesquisa.' : 'Crie o primeiro registo para começar a organizar a elegibilidade do clube.'} action={!search && <ShellButton onClick={() => setOpen(true)} testId="button-empty-create-player"><Plus className="h-4 w-4" /> Criar jogador</ShellButton>} /> : <div className="overflow-hidden rounded-2xl border border-[#dde3d8] bg-[#fbfcf7]" data-testid="players-table"><div className="hidden grid-cols-[1.6fr_1fr_.8fr_1fr_.8fr] gap-4 border-b border-[#e4e8df] bg-[#f3f6ef] px-5 py-3 font-mono text-[9px] uppercase tracking-[.14em] text-[#879287] md:grid"><span>Jogador</span><span>Identificação</span><span>Posição</span><span>Equipa</span><span>Estado</span></div>{list.map((player) => <div key={player.id} className="grid gap-3 border-b border-[#e8ebe4] px-5 py-4 last:border-0 md:grid-cols-[1.6fr_1fr_.8fr_1fr_.8fr] md:items-center md:gap-4" data-testid={`row-player-${player.id}`}><div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e7eef8] text-xs font-extrabold text-[#49658e]">{player.fullName.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><div><p className="text-sm font-bold text-[#33415e]" data-testid={`text-player-name-${player.id}`}>{player.fullName}</p><p className="mt-0.5 text-[11px] text-[#899488]">N.º AFP {String(player.id).padStart(4, '0')}</p></div></div><div className="text-xs text-[#657266]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Identificação · </span>{player.nationalId}</div><div className="text-xs font-semibold text-[#52634e]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Posição · </span>{player.position}</div><div className="text-xs text-[#657266]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Equipa · </span>{player.teamName ?? 'Sem equipa'}</div><div><StatusTag tone={player.authStatus === 'verified' ? 'green' : player.authStatus === 'pending' ? 'amber' : 'neutral'}>{player.authStatus === 'verified' ? 'Verificado' : player.authStatus === 'pending' ? 'Em análise' : 'Por verificar'}</StatusTag></div></div>)}</div>}{open && <Modal title="Adicionar jogador" description="Registe os dados essenciais do jogador. Poderá completar a documentação depois." onClose={() => { setOpen(false); setFeedback(''); }}><form onSubmit={submit} className="space-y-4" noValidate><div className="grid gap-4 sm:grid-cols-2"><FormField label="Nome completo" value={form.fullName} onChange={(value) => setForm({ ...form, fullName: value })} placeholder="Ex.: Ricardo Alves" testId="input-player-name" /><FormField label="Data de nascimento" type="date" value={form.birthDate} onChange={(value) => setForm({ ...form, birthDate: value })} testId="input-player-birthdate" /><FormField label="NIF / identificação" value={form.nationalId} onChange={(value) => setForm({ ...form, nationalId: value })} placeholder="Ex.: 245 981 730" testId="input-player-national-id" /><FormField label="Posição" value={form.position} onChange={(value) => setForm({ ...form, position: value })} placeholder="Ex.: Defesa central" testId="input-player-position" /></div><label className="block space-y-2"><span className="font-mono text-[10px] uppercase tracking-[.15em] text-[#667367]">Equipa</span><select value={form.teamId} onChange={(e) => setForm({ ...form, teamId: e.target.value })} className="h-11 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] px-3.5 text-sm text-[#33415e]" data-testid="select-player-team"><option value="">Sem equipa atribuída</option>{(teams.data ?? []).map((team) => <option key={team.id} value={team.id}>{team.name} · {team.category}</option>)}</select></label>{(feedback || create.isError) && <p className={`rounded-xl px-3 py-2 text-xs ${create.isError ? 'bg-[#fff0ed] text-[#a3493d]' : 'bg-[#e7f2ea] text-[#327051]'}`} role="alert" data-testid="feedback-player">{feedback || getErrorMessage(create.error)}</p>}<div className="flex justify-end gap-2 pt-3"><ShellButton variant="quiet" onClick={() => setOpen(false)} testId="button-cancel-player">Cancelar</ShellButton><ShellButton type="submit" disabled={create.isPending} testId="button-submit-player">{create.isPending ? 'A guardar...' : 'Guardar jogador'}</ShellButton></div></form></Modal>}</div>;
}

function TeamsPage() {
  const queryClient = useQueryClient();
  const teams = useAfpListClubTeams({ query: { queryKey: getAfpListClubTeamsQueryKey(), staleTime: 30000 } });
  const create = useAfpCreateClubTeam();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', category: '', season: '2024/25' });
  const [feedback, setFeedback] = useState('');
  const submit = (event: FormEvent) => { event.preventDefault(); if (!form.name.trim() || !form.category.trim() || !form.season.trim()) return setFeedback('Preencha os campos obrigatórios.'); create.mutate({ data: { name: form.name.trim(), category: form.category.trim(), season: form.season.trim() } }, { onSuccess: () => { setFeedback('Equipa criada com sucesso.'); setForm({ name: '', category: '', season: '2024/25' }); void queryClient.invalidateQueries({ queryKey: getAfpListClubTeamsQueryKey() }); void queryClient.invalidateQueries({ queryKey: getAfpGetClubDashboardQueryKey() }); setTimeout(() => { setOpen(false); setFeedback(''); }, 900); }, onError: (error) => setFeedback(getErrorMessage(error, 'Não foi possível criar a equipa.')) }); };
  return <div data-testid="teams-page"><WorkspaceHeader eyebrow="Estrutura desportiva" title="Equipas" description="Organize os plantéis por categoria e mantenha a época competitiva sob controlo." action={<ShellButton onClick={() => setOpen(true)} testId="button-create-team"><Plus className="h-4 w-4" /> Nova equipa</ShellButton>} />{teams.isLoading ? <PageSkeleton /> : teams.isError ? <ErrorState onRetry={() => void teams.refetch()} /> : (teams.data ?? []).length === 0 ? <EmptyState icon={Trophy} title="Ainda sem equipas" text="Crie a primeira equipa do clube para começar a associar jogadores." action={<ShellButton onClick={() => setOpen(true)} testId="button-empty-create-team"><Plus className="h-4 w-4" /> Criar equipa</ShellButton>} /> : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{(teams.data ?? []).map((team) => <article key={team.id} className="group relative overflow-hidden rounded-2xl border border-[#dde3d8] bg-[#fbfcf7] p-5 transition-transform hover:-translate-y-0.5" data-testid={`card-team-${team.id}`}><div className="absolute right-0 top-0 h-24 w-24 rounded-bl-[48px] bg-[#edf2e9]" /><div className="relative flex items-start justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#273a60] text-[#e7c84d]"><Trophy className="h-5 w-5" /></span><StatusTag tone="green">{team.status || 'Ativa'}</StatusTag></div><h2 className="relative mt-7 font-['Space_Grotesk'] text-2xl font-semibold tracking-[-.045em] text-[#33415e]">{team.name}</h2><p className="relative mt-1 text-xs text-[#788477]">{team.category} · Época {team.season}</p><div className="relative mt-7 flex items-center justify-between border-t border-[#e6eae2] pt-4"><span className="flex items-center gap-2 text-xs font-semibold text-[#657266]"><Users className="h-4 w-4 text-[#7d9378]" /> {team.playerCount} jogadores</span><ChevronRight className="h-4 w-4 text-[#9ca79b]" /></div></article>)}</div>}{open && <Modal title="Criar equipa" description="Defina a identidade competitiva da nova equipa." onClose={() => { setOpen(false); setFeedback(''); }}><form onSubmit={submit} className="space-y-4" noValidate><FormField label="Nome da equipa" value={form.name} onChange={(value) => setForm({ ...form, name: value })} placeholder="Ex.: Seniores A" testId="input-team-name" /><div className="grid gap-4 sm:grid-cols-2"><FormField label="Categoria" value={form.category} onChange={(value) => setForm({ ...form, category: value })} placeholder="Ex.: Masculino sénior" testId="input-team-category" /><FormField label="Época" value={form.season} onChange={(value) => setForm({ ...form, season: value })} placeholder="2024/25" testId="input-team-season" /></div>{(feedback || create.isError) && <p className={`rounded-xl px-3 py-2 text-xs ${create.isError ? 'bg-[#fff0ed] text-[#a3493d]' : 'bg-[#e7f2ea] text-[#327051]'}`} role="alert" data-testid="feedback-team">{feedback || getErrorMessage(create.error)}</p>}<div className="flex justify-end gap-2 pt-3"><ShellButton variant="quiet" onClick={() => setOpen(false)} testId="button-cancel-team">Cancelar</ShellButton><ShellButton type="submit" disabled={create.isPending} testId="button-submit-team">{create.isPending ? 'A guardar...' : 'Guardar equipa'}</ShellButton></div></form></Modal>}</div>;
}

function DocumentsPage() {
  const queryClient = useQueryClient();
  const documents = useAfpListClubDocuments({ query: { queryKey: getAfpListClubDocumentsQueryKey(), staleTime: 30000 } });
  const players = useAfpListClubPlayers({ query: { queryKey: getAfpListClubPlayersQueryKey(), staleTime: 30000 } });
  const create = useAfpCreateClubDocument();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ playerId: '', type: 'Cartão de cidadão', fileName: '', expiresAt: '' });
  const [feedback, setFeedback] = useState('');
  const submit = (event: FormEvent) => { event.preventDefault(); if (!form.playerId || !form.type.trim() || !form.fileName.trim()) return setFeedback('Selecione um jogador e preencha os campos obrigatórios.'); create.mutate({ data: { playerId: Number(form.playerId), type: form.type.trim(), fileName: form.fileName.trim(), expiresAt: form.expiresAt || null, objectPath: null } }, { onSuccess: () => { setFeedback('Documento registado com sucesso.'); setForm({ playerId: '', type: 'Cartão de cidadão', fileName: '', expiresAt: '' }); void queryClient.invalidateQueries({ queryKey: getAfpListClubDocumentsQueryKey() }); void queryClient.invalidateQueries({ queryKey: getAfpGetClubDashboardQueryKey() }); setTimeout(() => { setOpen(false); setFeedback(''); }, 900); }, onError: (error) => setFeedback(getErrorMessage(error, 'Não foi possível registar o documento.')) }); };
  return <div data-testid="documents-page"><WorkspaceHeader eyebrow="Arquivo documental" title="Documentos" description="Saiba que documentos estão válidos, pendentes ou a chegar ao fim de validade." action={<ShellButton onClick={() => setOpen(true)} testId="button-create-document"><Plus className="h-4 w-4" /> Registar documento</ShellButton>} />{documents.isLoading ? <PageSkeleton /> : documents.isError ? <ErrorState onRetry={() => void documents.refetch()} /> : (documents.data ?? []).length === 0 ? <EmptyState icon={FileText} title="Arquivo ainda vazio" text="Registe o primeiro documento de um jogador para criar o histórico documental do clube." action={<ShellButton onClick={() => setOpen(true)} testId="button-empty-create-document"><Plus className="h-4 w-4" /> Registar documento</ShellButton>} /> : <div className="overflow-hidden rounded-2xl border border-[#dde3d8] bg-[#fbfcf7]" data-testid="documents-table"><div className="hidden grid-cols-[1.4fr_1fr_1fr_1fr_.8fr] gap-4 border-b border-[#e4e8df] bg-[#f3f6ef] px-5 py-3 font-mono text-[9px] uppercase tracking-[.14em] text-[#879287] md:grid"><span>Documento</span><span>Jogador</span><span>Validade</span><span>Adicionado</span><span>Estado</span></div>{(documents.data ?? []).map((doc) => <div key={doc.id} className="grid gap-3 border-b border-[#e8ebe4] px-5 py-4 last:border-0 md:grid-cols-[1.4fr_1fr_1fr_1fr_.8fr] md:items-center md:gap-4" data-testid={`row-document-${doc.id}`}><div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#f5edd4] text-[#96731e]"><FileCheck2 className="h-4 w-4" /></span><div><p className="text-sm font-bold text-[#33415e]">{doc.type}</p><p className="mt-0.5 text-[11px] text-[#899488]">{doc.fileName}</p></div></div><p className="text-xs text-[#657266]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Jogador · </span>{doc.playerName ?? '—'}</p><p className="text-xs text-[#657266]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Validade · </span>{formatDate(doc.expiresAt)}</p><p className="text-xs text-[#657266]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Adicionado · </span>{formatDate(doc.createdAt)}</p><StatusTag tone={doc.status === 'valid' ? 'green' : doc.status === 'expired' ? 'red' : 'amber'}>{doc.status === 'valid' ? 'Válido' : doc.status === 'expired' ? 'Expirado' : 'Pendente'}</StatusTag></div>)}</div>}{open && <Modal title="Registar documento" description="Associe um documento existente a um jogador. O upload de ficheiros pode ser concluído no arquivo AFP." onClose={() => { setOpen(false); setFeedback(''); }}><form onSubmit={submit} className="space-y-4" noValidate><label className="block space-y-2"><span className="font-mono text-[10px] uppercase tracking-[.15em] text-[#667367]">Jogador *</span><select value={form.playerId} onChange={(e) => setForm({ ...form, playerId: e.target.value })} className="h-11 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] px-3.5 text-sm text-[#33415e]" data-testid="select-document-player"><option value="">Selecione um jogador</option>{(players.data ?? []).map((player) => <option key={player.id} value={player.id}>{player.fullName}</option>)}</select></label><div className="grid gap-4 sm:grid-cols-2"><FormField label="Tipo de documento" value={form.type} onChange={(value) => setForm({ ...form, type: value })} placeholder="Cartão de cidadão" testId="input-document-type" /><FormField label="Nome do ficheiro" value={form.fileName} onChange={(value) => setForm({ ...form, fileName: value })} placeholder="cc-ricardo-alves.pdf" testId="input-document-file" /></div><FormField label="Data de validade" type="date" required={false} value={form.expiresAt} onChange={(value) => setForm({ ...form, expiresAt: value })} testId="input-document-expiry" />{(feedback || create.isError) && <p className={`rounded-xl px-3 py-2 text-xs ${create.isError ? 'bg-[#fff0ed] text-[#a3493d]' : 'bg-[#e7f2ea] text-[#327051]'}`} role="alert" data-testid="feedback-document">{feedback || getErrorMessage(create.error)}</p>}<div className="flex justify-end gap-2 pt-3"><ShellButton variant="quiet" onClick={() => setOpen(false)} testId="button-cancel-document">Cancelar</ShellButton><ShellButton type="submit" disabled={create.isPending} testId="button-submit-document">{create.isPending ? 'A guardar...' : 'Registar documento'}</ShellButton></div></form></Modal>}</div>;
}

function RegistrationsPage() {
  const queryClient = useQueryClient();
  const registrations = useAfpListClubRegistrations({ query: { queryKey: getAfpListClubRegistrationsQueryKey(), staleTime: 30000 } });
  const players = useAfpListClubPlayers({ query: { queryKey: getAfpListClubPlayersQueryKey(), staleTime: 30000 } });
  const teams = useAfpListClubTeams({ query: { queryKey: getAfpListClubTeamsQueryKey(), staleTime: 30000 } });
  const create = useAfpCreateClubRegistration();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ playerId: string; teamId: string; competition: string; category: string; authMethod: AfpPlayerAuthMethod }>({ playerId: '', teamId: '', competition: '', category: '', authMethod: AfpPlayerAuthMethod.cmd });
  const [feedback, setFeedback] = useState('');
  const submit = (event: FormEvent) => { event.preventDefault(); if (!form.playerId || !form.competition.trim() || !form.category.trim()) return setFeedback('Selecione um jogador e preencha a competição e a categoria.'); create.mutate({ data: { playerId: Number(form.playerId), teamId: form.teamId ? Number(form.teamId) : null, competition: form.competition.trim(), category: form.category.trim(), authMethod: form.authMethod } }, { onSuccess: () => { setFeedback('Inscrição criada e enviada para a fila.'); setForm({ playerId: '', teamId: '', competition: '', category: '', authMethod: AfpPlayerAuthMethod.cmd }); void queryClient.invalidateQueries({ queryKey: getAfpListClubRegistrationsQueryKey() }); void queryClient.invalidateQueries({ queryKey: getAfpGetClubDashboardQueryKey() }); setTimeout(() => { setOpen(false); setFeedback(''); }, 900); }, onError: (error) => setFeedback(getErrorMessage(error, 'Não foi possível criar a inscrição.')) }); };
  const statusLabels: Record<string, string> = { draft: 'Rascunho', submitted: 'Submetida', under_review: 'Em análise', approved: 'Aprovada', needs_attention: 'Atenção' };
  return <div data-testid="registrations-page"><WorkspaceHeader eyebrow="Competições AFP" title="Inscrições" description="Acompanhe o ciclo de inscrição dos jogadores e prepare a próxima competição." action={<ShellButton onClick={() => setOpen(true)} testId="button-create-registration"><Plus className="h-4 w-4" /> Nova inscrição</ShellButton>} />{registrations.isLoading ? <PageSkeleton /> : registrations.isError ? <ErrorState onRetry={() => void registrations.refetch()} /> : (registrations.data ?? []).length === 0 ? <EmptyState icon={ClipboardList} title="Fila de inscrições vazia" text="Quando preparar a primeira inscrição, ela aparecerá aqui para acompanhamento." action={<ShellButton onClick={() => setOpen(true)} testId="button-empty-create-registration"><Plus className="h-4 w-4" /> Criar inscrição</ShellButton>} /> : <div className="overflow-hidden rounded-2xl border border-[#dde3d8] bg-[#fbfcf7]" data-testid="registrations-table"><div className="hidden grid-cols-[1.4fr_1.2fr_1fr_1fr_.8fr] gap-4 border-b border-[#e4e8df] bg-[#f3f6ef] px-5 py-3 font-mono text-[9px] uppercase tracking-[.14em] text-[#879287] md:grid"><span>Jogador</span><span>Competição</span><span>Categoria</span><span>Autenticação</span><span>Estado</span></div>{(registrations.data ?? []).map((registration) => <div key={registration.id} className="grid gap-3 border-b border-[#e8ebe4] px-5 py-4 last:border-0 md:grid-cols-[1.4fr_1.2fr_1fr_1fr_.8fr] md:items-center md:gap-4" data-testid={`row-registration-${registration.id}`}><div><p className="text-sm font-bold text-[#33415e]">{registration.playerName}</p><p className="mt-1 text-[11px] text-[#899488]">{registration.teamName ?? 'Sem equipa'} · {formatDate(registration.createdAt)}</p></div><p className="text-xs text-[#657266]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Competição · </span>{registration.competition}</p><p className="text-xs text-[#657266]"><span className="md:hidden font-mono text-[9px] uppercase text-[#a0a89e]">Categoria · </span>{registration.category}</p><p className="flex items-center gap-2 text-xs font-semibold text-[#657266]"><CreditCard className="h-3.5 w-3.5 text-[#7188a8]" />{registration.authMethod === 'citizen_card' ? 'Cartão de cidadão' : registration.authMethod === 'cmd' ? 'CMD' : 'Manual'}</p><StatusTag tone={registration.status === 'approved' ? 'green' : registration.status === 'needs_attention' ? 'red' : registration.status === 'under_review' ? 'blue' : 'amber'}>{statusLabels[registration.status] ?? registration.status}</StatusTag></div>)}</div>}{open && <Modal title="Criar inscrição" description="Prepare a inscrição de um jogador para uma competição oficial." onClose={() => { setOpen(false); setFeedback(''); }}><form onSubmit={submit} className="space-y-4" noValidate><label className="block space-y-2"><span className="font-mono text-[10px] uppercase tracking-[.15em] text-[#667367]">Jogador *</span><select value={form.playerId} onChange={(e) => setForm({ ...form, playerId: e.target.value })} className="h-11 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] px-3.5 text-sm text-[#33415e]" data-testid="select-registration-player"><option value="">Selecione um jogador</option>{(players.data ?? []).map((player) => <option key={player.id} value={player.id}>{player.fullName}</option>)}</select></label><label className="block space-y-2"><span className="font-mono text-[10px] uppercase tracking-[.15em] text-[#667367]">Equipa</span><select value={form.teamId} onChange={(e) => setForm({ ...form, teamId: e.target.value })} className="h-11 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] px-3.5 text-sm text-[#33415e]" data-testid="select-registration-team"><option value="">Sem equipa</option>{(teams.data ?? []).map((team) => <option key={team.id} value={team.id}>{team.name}</option>)}</select></label><div className="grid gap-4 sm:grid-cols-2"><FormField label="Competição" value={form.competition} onChange={(value) => setForm({ ...form, competition: value })} placeholder="Taça AFP Barcelos" testId="input-registration-competition" /><FormField label="Categoria" value={form.category} onChange={(value) => setForm({ ...form, category: value })} placeholder="Seniores" testId="input-registration-category" /></div><label className="block space-y-2"><span className="font-mono text-[10px] uppercase tracking-[.15em] text-[#667367]">Método de autenticação *</span><select value={form.authMethod} onChange={(e) => setForm({ ...form, authMethod: e.target.value as AfpPlayerAuthMethod })} className="h-11 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] px-3.5 text-sm text-[#33415e]" data-testid="select-registration-auth-method"><option value={AfpPlayerAuthMethod.cmd}>CMD</option><option value={AfpPlayerAuthMethod.citizen_card}>Cartão de cidadão</option><option value={AfpPlayerAuthMethod.manual}>Validação manual</option></select></label>{(feedback || create.isError) && <p className={`rounded-xl px-3 py-2 text-xs ${create.isError ? 'bg-[#fff0ed] text-[#a3493d]' : 'bg-[#e7f2ea] text-[#327051]'}`} role="alert" data-testid="feedback-registration">{feedback || getErrorMessage(create.error)}</p>}<div className="flex justify-end gap-2 pt-3"><ShellButton variant="quiet" onClick={() => setOpen(false)} testId="button-cancel-registration">Cancelar</ShellButton><ShellButton type="submit" disabled={create.isPending} testId="button-submit-registration">{create.isPending ? 'A enviar...' : 'Criar inscrição'}</ShellButton></div></form></Modal>}</div>;
}

function PlayerAuthPage() {
  const queryClient = useQueryClient();
  const players = useAfpListClubPlayers({ query: { queryKey: getAfpListClubPlayersQueryKey(), staleTime: 30000 } });
  const options = useAfpGetPlayerAuthOptions({ query: { queryKey: getAfpGetPlayerAuthOptionsQueryKey(), staleTime: 300000 } });
  const start = useAfpStartPlayerAuth();
  const [playerId, setPlayerId] = useState('');
  const [result, setResult] = useState<{ status: string; message: string }>();
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const authResult = params.get('auth');
    const code = params.get('code');
    if (!authResult || !code) return;
    setResult(authResult === 'verified'
      ? { status: 'verified', message: 'A identidade foi confirmada e a elegibilidade do jogador foi atualizada.' }
      : { status: 'error', message: 'Não foi possível concluir a autenticação. Pode iniciar um novo pedido.' });
    if (authResult === 'verified') {
      void queryClient.invalidateQueries({ queryKey: getAfpListClubPlayersQueryKey() });
      void queryClient.invalidateQueries({ queryKey: getAfpGetClubDashboardQueryKey() });
    }
    window.history.replaceState({}, document.title, window.location.pathname);
  }, [queryClient]);
  const begin = (method: AfpPlayerAuthMethod) => {
    if (!playerId) return setResult({ status: 'error', message: 'Selecione primeiro um jogador.' });
    setResult(undefined);
    start.mutate({ data: { playerId: Number(playerId), method } }, { onSuccess: (response) => {
      if (response.authorizationUrl) {
        window.location.assign(response.authorizationUrl);
        return;
      }
      setResult({ status: response.status, message: response.message });
    }, onError: (error) => setResult({ status: 'error', message: getErrorMessage(error, 'Não foi possível iniciar a autenticação.') }) });
  };
  const providersReady = options.data?.status === 'ready';
  return (
    <div data-testid="player-auth-page">
      <WorkspaceHeader
        eyebrow="Centro de identidade"
        title="Autenticação de jogadores"
        description="Prepare a verificação de identidade necessária para inscrições e elegibilidade."
      />
      <div
        className={`mb-6 flex flex-col gap-3 rounded-2xl border p-5 sm:flex-row sm:items-center ${
          providersReady
            ? 'border-[#cde2d3] bg-[#eef8f0]'
            : 'border-[#eadfb9] bg-[#fff9e8]'
        }`}
        data-testid="provider-status-banner"
      >
        <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
          providersReady ? 'bg-[#d6ecd9] text-[#327051]' : 'bg-[#f5e6a7] text-[#8a6b16]'
        }`}>
          <KeyRound className="h-5 w-5" />
        </span>
        <div>
          <p className={`text-sm font-bold ${providersReady ? 'text-[#327051]' : 'text-[#665116]'}`}>
            {providersReady ? 'Fornecedores oficiais prontos' : 'Credenciais dos provedores ainda não configuradas'}
          </p>
          <p className={`mt-1 text-xs leading-5 ${providersReady ? 'text-[#52735b]' : 'text-[#887443]'}`}>
            {providersReady
              ? 'CMD e Cartão de Cidadão podem iniciar um fluxo seguro de autenticação.'
              : 'O serviço aguarda a configuração oficial dos fornecedores. Não será feito nenhum redirecionamento fictício.'}
          </p>
        </div>
      </div>
      {options.isError && (
        <div className="mb-5 rounded-xl border border-[#ead5ce] bg-[#fff6f1] px-4 py-3 text-xs text-[#89665d]" data-testid="auth-options-error">
          Não foi possível obter o estado dos provedores neste momento.
        </div>
      )}
      <div className="grid gap-5 xl:grid-cols-[.8fr_1.2fr]">
        <section className="rounded-2xl border border-[#dde3d8] bg-[#fbfcf7] p-6">
          <p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#9a7513]">1 · Escolher jogador</p>
          <h2 className="mt-2 font-['Space_Grotesk'] text-xl font-semibold tracking-[-.04em] text-[#33415e]">Quem precisa de validação?</h2>
          <p className="mt-2 text-xs leading-5 text-[#7b857a]">A ação ficará registada no perfil do jogador selecionado.</p>
          <label className="mt-6 block space-y-2">
            <span className="font-mono text-[10px] uppercase tracking-[.15em] text-[#667367]">Jogador</span>
            <select value={playerId} onChange={(e) => setPlayerId(e.target.value)} className="h-11 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] px-3.5 text-sm text-[#33415e]" data-testid="select-auth-player">
              <option value="">Selecione um jogador</option>
              {(players.data ?? []).map((player) => (
                <option key={player.id} value={player.id}>
                  {player.fullName} · {player.authStatus === 'verified' ? 'verificado' : 'por verificar'}
                </option>
              ))}
            </select>
          </label>
          {players.isLoading && <p className="mt-3 text-xs text-[#829080]">A carregar jogadores...</p>}
          {players.isError && <p className="mt-3 text-xs text-[#a3493d]">Não foi possível carregar jogadores.</p>}
          {result && (
            <div className={`mt-5 rounded-xl border px-4 py-3 ${
              result.status === 'provider_configuration_required'
                ? 'border-[#eadfb9] bg-[#fff9e8] text-[#80661a]'
                : result.status === 'error'
                  ? 'border-[#ead5ce] bg-[#fff6f1] text-[#a3493d]'
                  : 'border-[#cde2d3] bg-[#eef8f0] text-[#327051]'
            }`} role="status" data-testid="auth-result">
              <p className="text-xs font-bold">
                {result.status === 'provider_configuration_required' ? 'Configuração necessária' : result.status === 'error' ? 'Pedido não concluído' : 'Estado atualizado'}
              </p>
              <p className="mt-1 text-xs leading-5">{result.message}</p>
            </div>
          )}
        </section>
        <section className="rounded-2xl border border-[#dde3d8] bg-[#fbfcf7] p-6">
          <p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#9a7513]">2 · Método de verificação</p>
          <h2 className="mt-2 font-['Space_Grotesk'] text-xl font-semibold tracking-[-.04em] text-[#33415e]">Escolha uma via segura</h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <button type="button" onClick={() => begin(AfpPlayerAuthMethod.cmd)} disabled={start.isPending} className="group rounded-2xl border border-[#d8dfd4] bg-[#f8faf5] p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[#9eae9e] disabled:opacity-50" data-testid="button-auth-cmd">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e7eef8] text-[#49658e]"><ShieldCheck className="h-5 w-5" /></span>
              <p className="mt-4 text-sm font-bold text-[#33415e]">CMD</p>
              <p className="mt-1 text-[11px] leading-5 text-[#7c887c]">Chave Móvel Digital</p>
              <span className="mt-5 flex items-center gap-1 text-[10px] font-bold text-[#9a7513]">Iniciar <ArrowRight className="h-3 w-3" /></span>
            </button>
            <button type="button" onClick={() => begin(AfpPlayerAuthMethod.citizen_card)} disabled={start.isPending} className="group rounded-2xl border border-[#d8dfd4] bg-[#f8faf5] p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[#9eae9e] disabled:opacity-50" data-testid="button-auth-citizen-card">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f5edd4] text-[#96731e]"><CreditCard className="h-5 w-5" /></span>
              <p className="mt-4 text-sm font-bold text-[#33415e]">Cartão de Cidadão</p>
              <p className="mt-1 text-[11px] leading-5 text-[#7c887c]">Leitura e validação segura</p>
              <span className="mt-5 flex items-center gap-1 text-[10px] font-bold text-[#9a7513]">Iniciar <ArrowRight className="h-3 w-3" /></span>
            </button>
            <button type="button" onClick={() => begin(AfpPlayerAuthMethod.manual)} disabled={start.isPending} className="group rounded-2xl border border-[#d8dfd4] bg-[#f8faf5] p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[#9eae9e] disabled:opacity-50" data-testid="button-auth-manual">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e5f1e8] text-[#3f7b5b]"><FileCheck2 className="h-5 w-5" /></span>
              <p className="mt-4 text-sm font-bold text-[#33415e]">Validação manual</p>
              <p className="mt-1 text-[11px] leading-5 text-[#7c887c]">Fluxo assistido pela AFP</p>
              <span className="mt-5 flex items-center gap-1 text-[10px] font-bold text-[#9a7513]">Iniciar <ArrowRight className="h-3 w-3" /></span>
            </button>
          </div>
          {start.isPending && <div className="mt-5 flex items-center gap-2 text-xs text-[#6c7e6d]" data-testid="auth-loading"><RefreshCw className="h-3.5 w-3.5 animate-spin" /> A contactar o serviço de identidade...</div>}
        </section>
      </div>
    </div>
  );
}

function ClubWorkspace({ session }: { session: AfpAuthSession }) {
  const [location] = useLocation();
  const active = (location.split('/').filter(Boolean).pop() || 'dashboard') as WorkspacePage;
  const page = active === 'players' ? <PlayersPage /> : active === 'teams' ? <TeamsPage /> : active === 'documents' ? <DocumentsPage /> : active === 'registrations' ? <RegistrationsPage /> : active === 'player-auth' ? <PlayerAuthPage /> : <DashboardPage />;
  return <WorkspaceShell session={session} active={active}>{page}</WorkspaceShell>;
}

function ProtectedClubRoute() {
  const current = useAfpGetCurrentUser({ query: { retry: false, queryKey: getAfpGetCurrentUserQueryKey() } });
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (current.isLoading) return;
    if (!current.data) {
      setLocation('/');
      return;
    }
    if (current.data.user.role !== AfpRole.club) {
      setLocation(roleDashboardPaths[current.data.user.role]);
    }
  }, [current.data, current.isLoading, setLocation]);
  if (current.isLoading) return <main className="afp-noise flex min-h-[100dvh] items-center justify-center bg-[#f2f5ee] px-6"><div className="w-full max-w-xl"><PageSkeleton /></div></main>;
  if (!current.data) {
    return null;
  }
  if (current.data.user.role !== AfpRole.club) return null;
  return <ClubWorkspace session={current.data} />;
}

function RoleDashboardRoute({ role }: { role: AfpRoleValue }) {
  const current = useAfpGetCurrentUser({ query: { retry: false, queryKey: getAfpGetCurrentUserQueryKey() } });
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (current.isLoading) return;
    if (!current.data) {
      setLocation('/');
      return;
    }
    if (current.data.user.role !== role) {
      setLocation(roleDashboardPaths[current.data.user.role]);
    }
  }, [current.data, current.isLoading, role, setLocation]);
  if (current.isLoading) return <main className="afp-noise flex min-h-[100dvh] items-center justify-center bg-[#f2f5ee] px-6"><div className="w-full max-w-xl"><PageSkeleton /></div></main>;
  if (!current.data || current.data.user.role !== role) return null;
  return <RoleDashboard session={current.data} />;
}

function RefereeDashboardRoute() {
  return <RoleDashboardRoute role={AfpRole.referee} />;
}

function ObserverDashboardRoute() {
  return <RoleDashboardRoute role={AfpRole.observer} />;
}

function BoardDashboardRoute() {
  return <RoleDashboardRoute role={AfpRole.board} />;
}

function BoardReviewPanel() {
  const queryClient = useQueryClient();
  const registrations = useAfpListBoardRegistrations({ query: { queryKey: getAfpListBoardRegistrationsQueryKey(), staleTime: 15000 } });
  const [selectedId, setSelectedId] = useState<number>();
  const documents = useAfpListBoardRegistrationDocuments(selectedId ?? 0, { query: { queryKey: getAfpListBoardRegistrationDocumentsQueryKey(selectedId ?? 0), enabled: Boolean(selectedId), staleTime: 10000 } });
  const review = useAfpReviewRegistrationDocument();
  const [note, setNote] = useState('');
  const selected = (registrations.data ?? []).find((item) => item.id === selectedId);
  const decide = (documentId: number, status: 'approved' | 'rejected') => {
    if (status === 'rejected' && !note.trim()) return;
    review.mutate({ documentId, data: { status, reviewNote: note.trim() || null } }, { onSuccess: () => { setNote(''); void queryClient.invalidateQueries({ queryKey: getAfpListBoardRegistrationsQueryKey() }); void queryClient.invalidateQueries({ queryKey: getAfpListBoardRegistrationDocumentsQueryKey(selectedId ?? 0) }); } });
  };
  return <section className="mt-8" data-testid="board-review-panel">
    <div className="mb-4"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#9a7513]">Fila de validação</p><h2 className="mt-2 font-['Space_Grotesk'] text-2xl font-semibold tracking-[-.045em] text-[#33415e]">Inscrições pendentes</h2><p className="mt-2 text-sm text-[#7f8a7e]">Abra os documentos enviados pelos clubes e decida cada item com registo da justificação.</p></div>
    <div className="grid gap-5 lg:grid-cols-[.9fr_1.1fr]">
      <div className="overflow-hidden rounded-2xl border border-[#dde3d8] bg-[#fbfcf7]">{registrations.isLoading ? <PageSkeleton /> : (registrations.data ?? []).filter((item) => item.status !== 'approved').map((item) => <button key={item.id} type="button" onClick={() => setSelectedId(item.id)} className={`block w-full border-b border-[#e7ebe3] p-4 text-left last:border-0 ${selectedId === item.id ? 'bg-[#eef2e9]' : 'hover:bg-white'}`}><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-bold text-[#33415e]">{item.playerName}</p><p className="mt-1 text-xs text-[#7f8a7e]">{item.competition} · {item.category}</p></div><StatusTag tone={item.rejectedDocumentCount ? 'red' : 'amber'}>{item.rejectedDocumentCount ? 'Atenção' : 'Por verificar'}</StatusTag></div><p className="mt-3 text-[11px] text-[#718071]">{item.documentCount} documentos · {item.pendingDocumentCount} pendentes</p></button>)}{!registrations.isLoading && !(registrations.data ?? []).some((item) => item.status !== 'approved') && <EmptyState icon={CircleCheck} title="Fila limpa" text="Não existem inscrições pendentes de verificação." />}</div>
      <div className="rounded-2xl border border-[#dde3d8] bg-[#fbfcf7] p-5">{!selected ? <div className="flex min-h-[220px] items-center justify-center text-center text-sm text-[#879287]">Selecione uma inscrição para consultar os documentos.</div> : <><div className="flex items-start justify-between gap-3 border-b border-[#e7ebe3] pb-4"><div><p className="font-mono text-[10px] uppercase tracking-[.15em] text-[#9a7513]">Inscrição #{selected.id}</p><h3 className="mt-2 text-lg font-bold text-[#33415e]">{selected.playerName}</h3><p className="mt-1 text-xs text-[#7f8a7e]">{selected.competition} · {selected.teamName ?? 'Sem equipa'}</p></div><StatusTag tone={selected.status === 'needs_attention' ? 'red' : 'blue'}>{selected.status === 'needs_attention' ? 'Precisa de correção' : 'Em análise'}</StatusTag></div><div className="mt-4 space-y-3">{(documents.data ?? []).map((doc) => <div key={doc.id} className="rounded-xl border border-[#e5e9df] bg-white p-4"><div className="flex items-center justify-between gap-3"><div className="flex items-center gap-3"><FileCheck2 className="h-4 w-4 text-[#7188a8]" /><div><p className="text-sm font-bold text-[#33415e]">{doc.documentType}</p><p className="text-[11px] text-[#899488]">{doc.fileName}</p></div></div><StatusTag tone={doc.status === 'approved' ? 'green' : doc.status === 'rejected' ? 'red' : 'amber'}>{doc.status === 'approved' ? 'Aprovado' : doc.status === 'rejected' ? 'Rejeitado' : 'Por verificar'}</StatusTag></div><a href={`/api/afp/registration-documents/${doc.id}/file`} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-2 text-xs font-bold text-[#49658e] hover:underline"><Eye className="h-3.5 w-3.5" /> Abrir documento</a>{doc.status === 'pending' && <div className="mt-3 border-t border-[#eef0eb] pt-3"><textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="Justificação obrigatória apenas se rejeitar..." className="min-h-16 w-full rounded-xl border border-[#d8dfd4] bg-[#fbfcf7] p-3 text-xs text-[#33415e]" /><div className="mt-2 flex justify-end gap-2"><ShellButton variant="quiet" onClick={() => decide(doc.id, 'rejected')} disabled={review.isPending}>Rejeitar</ShellButton><ShellButton onClick={() => decide(doc.id, 'approved')} disabled={review.isPending}>Aprovar</ShellButton></div></div>}{doc.status === 'rejected' && doc.reviewNote && <p className="mt-3 rounded-lg bg-[#fff2ef] px-3 py-2 text-xs text-[#a3493d]"><strong>Justificação:</strong> {doc.reviewNote}</p>}</div>)}</div></>}</div>
    </div>
  </section>;
}

function RoleDashboard({ session }: { session: AfpAuthSession }) {
  const logout = useAfpLogout();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const content = roleDashboardContent[session.user.role];
  const firstName = session.user.name.split(' ')[0] || session.user.name;
  const doLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.removeQueries({ queryKey: getAfpGetCurrentUserQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getAfpGetAuthSummaryQueryKey() });
        setLocation('/');
      },
    });
  };
  return (
    <main className="afp-noise min-h-[100dvh] bg-[#f2f5ee] px-5 py-7 text-[#273a60] sm:px-8 sm:py-9 lg:px-12" data-testid={`${session.user.role}-dashboard`}>
      <div className="mx-auto max-w-[1320px]">
        <header className="flex items-center justify-between">
          <BrandMark />
          <div className="flex items-center gap-3">
            <StatusPill healthy />
            <button type="button" onClick={doLogout} disabled={logout.isPending} className="inline-flex items-center gap-2 rounded-xl border border-[#d9dfd5] bg-[#fbfcf7] px-3.5 py-2.5 text-xs font-bold text-[#59645c] transition-colors hover:border-[#b8beb2] hover:bg-white disabled:opacity-50" data-testid="button-role-dashboard-logout"><LogOut className="h-4 w-4" />{logout.isPending ? 'A terminar...' : 'Terminar sessão'}</button>
          </div>
        </header>
        {logout.isError && <p className="mt-4 text-right text-xs text-[#a14940]" role="alert" data-testid="alert-role-dashboard-logout">{getErrorMessage(logout.error, 'Não foi possível terminar a sessão.')}</p>}
        <div className="mt-10 grid gap-5 lg:grid-cols-[1.25fr_.75fr]">
          <section className="relative overflow-hidden rounded-[28px] bg-[#263451] px-7 py-9 text-[#fbf4e3] shadow-[0_24px_50px_-30px_rgba(38,52,81,.55)] sm:px-10 sm:py-11">
            <div className="absolute -right-10 -top-16 h-56 w-56 rounded-full border-[26px] border-[#f4d15f]/10" />
            <div className="absolute right-4 top-8 h-28 w-28 rounded-full border border-[#f4d15f]/25" />
            <div className="relative">
              <p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#d7c572]">{content.eyebrow}</p>
              <h1 className="mt-4 font-['Space_Grotesk'] text-[clamp(36px,5vw,58px)] font-semibold leading-none tracking-[-.065em]">Bom dia,<br />{firstName}.</h1>
              <p className="mt-5 max-w-[530px] text-sm leading-6 text-[#c9ccc3]">{content.description}</p>
              <div className="mt-8 inline-flex items-center gap-2 rounded-xl bg-[#344566] px-3.5 py-2.5 text-xs font-semibold text-[#e5e7df]"><BadgeCheck className="h-4 w-4 text-[#e7c84d]" /> Identidade confirmada pela AFP</div>
            </div>
          </section>
          <aside className="rounded-[28px] border border-[#dde3d8] bg-[#fbfcf7] p-7 shadow-[0_18px_40px_-30px_rgba(39,58,96,.45)] sm:p-8">
            <p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#9a7513]">Conta autenticada</p>
            <div className="mt-6 flex items-center gap-4 border-b border-[#e5e9df] pb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f4d15f] font-['Space_Grotesk'] text-xl font-bold text-[#263451]">{session.user.name.charAt(0)}</div>
              <div className="min-w-0">
                <p className="truncate font-semibold text-[#263451]" data-testid="text-session-user">{session.user.name}</p>
                <p className="mt-1 truncate text-xs text-[#7d857c]" data-testid="text-session-affiliation">{session.user.affiliation}</p>
              </div>
            </div>
            <dl className="grid gap-5 pt-6">
              <div><dt className="font-mono text-[9px] uppercase tracking-[.15em] text-[#8b9189]">Perfil</dt><dd className="mt-2 text-sm font-semibold text-[#263451]">{session.user.roleLabel}</dd></div>
              <div><dt className="font-mono text-[9px] uppercase tracking-[.15em] text-[#8b9189]">Contacto</dt><dd className="truncate text-sm font-semibold text-[#263451]">{session.user.email}</dd></div>
            </dl>
          </aside>
        </div>
         {session.user.role === AfpRole.board ? <BoardReviewPanel /> : <section className="mt-8">
          <div className="mb-4 flex items-end justify-between gap-4">
            <div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-[#9a7513]">Acesso rápido</p><h2 className="mt-2 font-['Space_Grotesk'] text-2xl font-semibold tracking-[-.045em] text-[#33415e]">As suas áreas de trabalho</h2></div>
            <span className="hidden text-xs text-[#819080] sm:block">Sessão protegida · AFP Barcelos</span>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {content.modules.map(({ label, text, icon: Icon }) => <article key={label} className="rounded-2xl border border-[#dde3d8] bg-[#fbfcf7] p-5 shadow-[0_12px_30px_-26px_rgba(39,58,96,.8)]"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e8eef8] text-[#49658e]"><Icon className="h-[18px] w-[18px]" /></span><h3 className="mt-5 text-sm font-bold text-[#33415e]">{label}</h3><p className="mt-1 text-xs leading-5 text-[#7f8a7e]">{text}</p><div className="mt-5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.1em] text-[#9a7513]"><span className="h-1.5 w-1.5 rounded-full bg-[#e7c84d]" /> Área disponível</div></article>)}
          </div>
         </section>}
        <section className="mt-5 rounded-2xl border border-[#dde3d8] bg-[#eef2e9] px-5 py-4 text-xs leading-5 text-[#687868]"><span className="font-bold text-[#52634e]">Painel personalizado para {content.area.toLowerCase()}.</span> As ferramentas e notificações desta área aparecerão aqui à medida que forem disponibilizadas.</section>
      </div>
    </main>
  );
}

function Home() {
  const [authMode, setAuthMode] = useState<'landing' | 'login' | 'register'>('landing');
  const [selectedRole, setSelectedRole] = useState<AfpRoleValue>();
  const [showUnavailable, setShowUnavailable] = useState(false);
  const [, setLocation] = useLocation();
  const current = useAfpGetCurrentUser({ query: { retry: false, queryKey: getAfpGetCurrentUserQueryKey() } });
  const options = useAfpGetLoginOptions({ query: { retry: 1, staleTime: 300000, queryKey: getAfpGetLoginOptionsQueryKey() } });
  const summary = useAfpGetAuthSummary({ query: { retry: 1, staleTime: 60000, queryKey: getAfpGetAuthSummaryQueryKey() } });
  const health = useHealthCheck({ query: { retry: false, queryKey: getHealthCheckQueryKey() } });

  const roles = useMemo(() => (options.data?.roles ?? []).map((role) => role), [options.data]);
  const hasApiIssue = Boolean((options.isError || health.isError) && !options.isFetching);

  if (current.isLoading) {
    return <main className="afp-noise flex min-h-[100dvh] items-center justify-center bg-[#f4f2e9] px-6"><div className="w-full max-w-[470px]"><LoadingPanel label="A recuperar a sessão AFP" /></div></main>;
  }

  if (current.data) {
    if (current.data.user.role === AfpRole.club) {
      return <ClubWorkspace session={current.data} />;
    }
    return <RoleDashboard session={current.data} />;
  }

  return (
    <main className="afp-noise min-h-[100dvh] bg-[#f4f2e9]">
      <div className="flex min-h-[100dvh]">
        <SummaryRail summary={summary.data} summaryLoading={summary.isLoading} />
        <section className="afp-grid flex min-h-[100dvh] flex-1 flex-col px-5 py-7 sm:px-10 sm:py-10 lg:px-[clamp(40px,6vw,100px)]">
          <div className="mx-auto flex w-full max-w-[620px] flex-1 flex-col">
            <div className="flex items-center justify-between lg:justify-end">
              <div className="lg:hidden"><BrandMark /></div>
              <StatusPill healthy={health.isSuccess} loading={health.isLoading} />
            </div>
            {authMode === 'landing' ? (
              <div className="afp-rise afp-delay-1 mt-14 max-w-[580px] sm:mt-20 lg:mt-[clamp(64px,11vh,125px)]" data-testid="auth-entry">
                <p className="font-mono text-[10px] font-medium uppercase tracking-[.2em] text-[#8b8f83]">Portal AFP Barcelos · Época 2024 / 25</p>
                <h1 className="mt-4 font-['Space_Grotesk'] text-[clamp(38px,5vw,58px)] font-semibold leading-[.98] tracking-[-.065em] text-[#263451]">A sua área AFP<br /><span className="text-[#9b8121]">começa aqui.</span></h1>
                <p className="mt-5 max-w-[480px] text-sm leading-6 text-[#70786e]">Escolha como quer entrar no portal da Associação de Futebol Popular de Barcelos.</p>
                <div className="mt-9 grid gap-4 sm:grid-cols-2">
                  <button type="button" onClick={() => setAuthMode('login')} className="group rounded-2xl border border-[#263451] bg-[#263451] p-5 text-left text-[#fbf4e3] shadow-[0_16px_30px_-20px_rgba(38,52,81,.7)] transition-all hover:-translate-y-0.5 hover:bg-[#334566]" data-testid="button-start-login">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f4d15f] text-[#263451]"><LockKeyhole className="h-[18px] w-[18px]" /></span>
                    <span className="mt-5 block font-['Space_Grotesk'] text-xl font-semibold tracking-[-.04em]">Iniciar sessão</span>
                    <span className="mt-2 block text-xs leading-5 text-[#d6d9d1]">Já tem uma conta AFP? Entre no seu painel.</span>
                    <span className="mt-5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.12em] text-[#f4d15f]">Entrar no portal <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" /></span>
                  </button>
                  <button type="button" onClick={() => setAuthMode('register')} className="group rounded-2xl border border-[#d8dfd4] bg-[#fbfcf7] p-5 text-left text-[#263451] transition-all hover:-translate-y-0.5 hover:border-[#aebaaa] hover:bg-white" data-testid="button-start-register">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e5f1e8] text-[#3f7b5b]"><UserRound className="h-[18px] w-[18px]" /></span>
                    <span className="mt-5 block font-['Space_Grotesk'] text-xl font-semibold tracking-[-.04em]">Criar conta</span>
                    <span className="mt-2 block text-xs leading-5 text-[#7a857a]">Ainda não tem acesso? Registe-se em poucos passos.</span>
                    <span className="mt-5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.12em] text-[#9a7513]">Começar registo <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" /></span>
                  </button>
                </div>
              </div>
            ) : (
              <>
                <button type="button" onClick={() => { setAuthMode('landing'); setSelectedRole(undefined); }} className="afp-rise mt-10 inline-flex items-center gap-2 text-xs font-bold text-[#667367] hover:text-[#263451]" data-testid="button-back-auth-entry"><ArrowRight className="h-3.5 w-3.5 rotate-180" /> Voltar às opções</button>
                <div className="afp-rise afp-delay-1 mt-7 max-w-[560px]">
                  <p className="font-mono text-[10px] font-medium uppercase tracking-[.2em] text-[#8b8f83]">{authMode === 'login' ? 'Acesso reservado' : 'Novo acesso · Registo AFP'}</p>
                  <h1 className="mt-4 font-['Space_Grotesk'] text-[clamp(38px,5vw,58px)] font-semibold leading-[.98] tracking-[-.065em]">{authMode === 'login' ? <>Entre na sua<br /><span className="text-[#9b8121]">área AFP.</span></> : <>Crie a sua<br /><span className="text-[#9b8121]">conta AFP.</span></>}</h1>
                  <p className="mt-5 max-w-[460px] text-sm leading-6 text-[#70786e]">{authMode === 'login' ? 'Selecione o seu perfil e introduza os dados de acesso para continuar.' : 'Escolha o seu perfil e preencha os dados para criar um acesso personalizado.'}</p>
                </div>
                <div className="afp-rise afp-delay-2 mt-9">
                  <div className="mb-3 flex items-center justify-between">
                    <p className="font-mono text-[10px] font-medium uppercase tracking-[.18em] text-[#68716d]">Como participa?</p>
                    {selectedRole && <span className="text-[11px] font-semibold text-[#9b8121]" data-testid="text-selected-role">Perfil selecionado</span>}
                  </div>
                  {options.isLoading ? <LoadingPanel label="A carregar perfis disponíveis" /> : options.isError ? (
                    <div className="rounded-2xl border border-[#e4d5c9] bg-[#faf3eb] px-5 py-5 text-sm text-[#87644f]" data-testid="options-error"><div className="flex items-start gap-3"><CircleAlert className="mt-0.5 h-4 w-4 shrink-0" /><div><p className="font-semibold">Não conseguimos carregar os perfis.</p><p className="mt-1 text-xs leading-5">Verifique a ligação ao serviço AFP e tente novamente.</p><button type="button" onClick={() => void options.refetch()} className="mt-3 inline-flex items-center gap-2 text-xs font-bold text-[#263451] hover:underline" data-testid="button-retry-options"><RefreshCw className="h-3.5 w-3.5" /> Recarregar perfis</button></div></div></div>
                  ) : <RolePicker roles={roles} selectedRole={selectedRole} onRoleChange={setSelectedRole} />}
                </div>
                {roles.length > 0 && !showUnavailable && (
                  <div className="afp-rise afp-delay-3">{authMode === 'login' ? <LoginPanel roles={roles} selectedRole={selectedRole} onRoleChange={setSelectedRole} onSuccess={() => { if (selectedRole) setLocation(roleDashboardPaths[selectedRole]); }} /> : <RegisterPanel roles={roles} selectedRole={selectedRole} onRoleChange={setSelectedRole} onSuccess={() => { if (selectedRole) setLocation(roleDashboardPaths[selectedRole]); }} />}</div>
                )}
              </>
            )}
            {hasApiIssue && (
              <div className="mt-5 flex items-center justify-between gap-3 rounded-xl border border-[#e4d5c9] bg-[#faf3eb] px-4 py-3 text-xs text-[#87644f]" data-testid="banner-api-unavailable">
                <span>Alguns serviços AFP podem estar indisponíveis.</span>
                <button type="button" onClick={() => setShowUnavailable((value) => !value)} className="shrink-0 font-bold text-[#263451] hover:underline" data-testid="button-toggle-api-status">{showUnavailable ? 'Ocultar' : 'Ver estado'}</button>
              </div>
            )}
            {showUnavailable && (
              <div className="mt-3 rounded-xl border border-[#dedfd5] bg-[#fbfbf7] p-4 text-xs text-[#6c756d]" data-testid="panel-api-status"><p className="font-semibold text-[#263451]">Estado do serviço</p><p className="mt-1">O acesso requer uma ligação ativa à API da AFP Barcelos. Tente novamente dentro de momentos.</p><button type="button" onClick={() => { void options.refetch(); void health.refetch(); }} className="mt-3 inline-flex items-center gap-2 font-bold text-[#263451] hover:underline" data-testid="button-retry-api"><RefreshCw className="h-3.5 w-3.5" /> Verificar novamente</button></div>
            )}
            <OperationalSummary summary={summary.data} loading={summary.isLoading} error={summary.error} onRetry={() => void summary.refetch()} />
            <footer className="mt-auto flex flex-col gap-2 border-t border-[#e1e0d6] pt-5 text-[10px] uppercase tracking-[.13em] text-[#979a91] sm:flex-row sm:items-center sm:justify-between">
              <span>AFP Barcelos · Portal oficial</span>
              <span className="font-mono normal-case tracking-normal">Acesso exclusivo a utilizadores autorizados</span>
            </footer>
          </div>
        </section>
      </div>
    </main>
  );
}

function Router() {
  return (
    <ErrorBoundary resetKey={window.location.pathname}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/club/dashboard" component={ProtectedClubRoute} />
        <Route path="/club/players" component={ProtectedClubRoute} />
        <Route path="/club/teams" component={ProtectedClubRoute} />
        <Route path="/club/documents" component={ProtectedClubRoute} />
        <Route path="/club/registrations" component={ProtectedClubRoute} />
        <Route path="/club/player-auth" component={ProtectedClubRoute} />
        <Route path="/referee/dashboard" component={RefereeDashboardRoute} />
        <Route path="/observer/dashboard" component={ObserverDashboardRoute} />
        <Route path="/board/dashboard" component={BoardDashboardRoute} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
