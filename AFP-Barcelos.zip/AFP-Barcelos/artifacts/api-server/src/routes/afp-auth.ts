import { promisify } from "node:util";
import {
  createHash,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { Router, type IRouter, type Request } from "express";
import { and, count, eq, gt, lt } from "drizzle-orm";
import { db, afpRoleEnum, afpSessionsTable, afpUsersTable } from "@workspace/db";
import {
  AfpGetAuthSummaryResponse,
  AfpGetCurrentUserResponse,
  AfpGetLoginOptionsResponse,
  AfpLoginBody,
  AfpLoginResponse,
  AfpRegisterBody,
  AfpRegisterResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const sessionCookieName = "afp_barcelos_session";
const sessionDurationMs = 8 * 60 * 60 * 1000;
const scrypt = promisify(scryptCallback);

const roleLabels = {
  club: "Clubes",
  referee: "Árbitros",
  observer: "Observadores",
  board: "Direção",
} as const;

const roleDescriptions = {
  club: "Acesso de dirigentes e representantes dos clubes associados.",
  referee: "Área reservada aos árbitros da associação.",
  observer: "Acesso dos observadores de jogos e equipas de arbitragem.",
  board: "Área de trabalho da direção da AFP Barcelos.",
} as const;

type AfpRole = keyof typeof roleLabels;

function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    maxAge: sessionDurationMs,
    path: "/",
  };
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

async function hashPassword(
  password: string,
  salt = randomBytes(16).toString("hex"),
) {
  const derivedKey = (await scrypt(password, salt, 64)) as Buffer;
  return { hash: derivedKey.toString("hex"), salt };
}

async function passwordMatches(password: string, hash: string, salt: string) {
  const candidate = (await scrypt(password, salt, 64)) as Buffer;
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

async function createSession(userId: number) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + sessionDurationMs);

  await db.insert(afpSessionsTable).values({
    userId,
    tokenHash: hashToken(token),
    expiresAt,
  });

  return token;
}

export async function getSessionUser(req: Request) {
  const token = req.cookies?.[sessionCookieName];
  if (typeof token !== "string" || token.length === 0) {
    return null;
  }

  const rows = await db
    .select({
      session: afpSessionsTable,
      user: afpUsersTable,
    })
    .from(afpSessionsTable)
    .innerJoin(afpUsersTable, eq(afpSessionsTable.userId, afpUsersTable.id))
    .where(
      and(
        eq(afpSessionsTable.tokenHash, hashToken(token)),
        gt(afpSessionsTable.expiresAt, new Date()),
      ),
    )
    .limit(1);

  return rows[0] ?? null;
}

function userResponse(
  user: typeof afpUsersTable.$inferSelect,
  signedInAt: Date,
) {
  return {
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      affiliation: user.affiliation,
      roleLabel: roleLabels[user.role],
      createdAt: user.createdAt,
    },
    signedInAt,
  };
}

export async function seedAfpDemoAccounts() {
  if (process.env.NODE_ENV === "production") {
    return;
  }

  const demoPassword = "afp-demo-2026";
  const demoAccounts: Array<{
    name: string;
    email: string;
    role: AfpRole;
    affiliation: string;
  }> = [
    {
      name: "Conta de Clube",
      email: "clubes@afpbarcelos.pt",
      role: "club",
      affiliation: "Clube de Demonstração",
    },
    {
      name: "Conta de Árbitro",
      email: "arbitros@afpbarcelos.pt",
      role: "referee",
      affiliation: "Árbitros AFP Barcelos",
    },
    {
      name: "Conta de Observador",
      email: "observadores@afpbarcelos.pt",
      role: "observer",
      affiliation: "Observadores AFP Barcelos",
    },
    {
      name: "Conta da Direção",
      email: "direcao@afpbarcelos.pt",
      role: "board",
      affiliation: "Direção AFP Barcelos",
    },
  ];

  for (const account of demoAccounts) {
    const existing = await db
      .select({ id: afpUsersTable.id })
      .from(afpUsersTable)
      .where(eq(afpUsersTable.email, account.email))
      .limit(1);

    if (existing.length > 0) {
      continue;
    }

    const password = await hashPassword(demoPassword);
    await db.insert(afpUsersTable).values({
      ...account,
      passwordHash: password.hash,
      passwordSalt: password.salt,
    });
  }
}

router.get("/afp/auth/options", (_req, res): void => {
  res.json(
    AfpGetLoginOptionsResponse.parse({
      roles: (Object.keys(roleLabels) as AfpRole[]).map((role) => ({
        role,
        label: roleLabels[role],
        description: roleDescriptions[role],
      })),
    }),
  );
});

router.post("/afp/auth/login", async (req, res): Promise<void> => {
  const parsed = AfpLoginBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.flatten() }, "Invalid AFP login body");
    res.status(400).json({ error: "Indica o perfil, email e palavra-passe." });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const [user] = await db
    .select()
    .from(afpUsersTable)
    .where(
      and(
        eq(afpUsersTable.email, email),
        eq(afpUsersTable.role, parsed.data.role),
      ),
    )
    .limit(1);

  if (
    !user ||
    !(await passwordMatches(parsed.data.password, user.passwordHash, user.passwordSalt))
  ) {
    req.log.info({ email, role: parsed.data.role }, "Rejected AFP login attempt");
    res.status(401).json({ error: "Os dados de acesso não correspondem a este perfil." });
    return;
  }

  const token = await createSession(user.id);
  res.cookie(sessionCookieName, token, cookieOptions());
  res.json(AfpLoginResponse.parse(userResponse(user, new Date())));
});

router.post("/afp/auth/register", async (req, res): Promise<void> => {
  const parsed = AfpRegisterBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.flatten() }, "Invalid AFP registration body");
    res.status(400).json({ error: "Preenche todos os campos com dados válidos para criar a conta." });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const [existingUser] = await db
    .select({ id: afpUsersTable.id })
    .from(afpUsersTable)
    .where(eq(afpUsersTable.email, email))
    .limit(1);

  if (existingUser) {
    res.status(409).json({ error: "Já existe uma conta AFP com este email." });
    return;
  }

  const password = await hashPassword(parsed.data.password);
  const [user] = await db
    .insert(afpUsersTable)
    .values({
      name: parsed.data.name.trim(),
      email,
      passwordHash: password.hash,
      passwordSalt: password.salt,
      role: parsed.data.role,
      affiliation: parsed.data.affiliation.trim(),
    })
    .returning();

  const token = await createSession(user.id);
  res.cookie(sessionCookieName, token, cookieOptions());
  res.status(201).json(AfpRegisterResponse.parse(userResponse(user, new Date())));
});

router.get("/afp/auth/me", async (req, res): Promise<void> => {
  const session = await getSessionUser(req);
  if (!session) {
    res.status(401).json({ error: "Não existe uma sessão AFP ativa." });
    return;
  }

  res.json(
    AfpGetCurrentUserResponse.parse(
      userResponse(session.user, session.session.createdAt),
    ),
  );
});

router.post("/afp/auth/logout", async (req, res): Promise<void> => {
  const token = req.cookies?.[sessionCookieName];
  if (typeof token === "string" && token.length > 0) {
    await db
      .delete(afpSessionsTable)
      .where(eq(afpSessionsTable.tokenHash, hashToken(token)));
  }

  res.clearCookie(sessionCookieName, cookieOptions());
  res.sendStatus(204);
});

router.get("/afp/auth/summary", async (_req, res): Promise<void> => {
  const now = new Date();
  await db.delete(afpSessionsTable).where(lt(afpSessionsTable.expiresAt, now));

  const [users, sessions, groupedUsers] = await Promise.all([
    db.select({ value: count() }).from(afpUsersTable),
    db
      .select({ value: count() })
      .from(afpSessionsTable)
      .where(gt(afpSessionsTable.expiresAt, now)),
    db
      .select({ role: afpUsersTable.role, value: count() })
      .from(afpUsersTable)
      .groupBy(afpUsersTable.role),
  ]);

  const counts = new Map(groupedUsers.map((entry) => [entry.role, Number(entry.value)]));
  res.json(
    AfpGetAuthSummaryResponse.parse({
      totalUsers: Number(users[0]?.value ?? 0),
      activeSessions: Number(sessions[0]?.value ?? 0),
      roles: (Object.keys(roleLabels) as AfpRole[]).map((role) => ({
        role,
        label: roleLabels[role],
        count: counts.get(role) ?? 0,
      })),
    }),
  );
});

export default router;