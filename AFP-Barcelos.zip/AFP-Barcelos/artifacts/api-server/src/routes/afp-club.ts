import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { Router, type IRouter, type Request } from "express";
import { and, asc, count, eq } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  afpDocumentsTable,
  afpPlayersTable,
  afpRegistrationsTable,
  afpTeamsTable,
} from "@workspace/db";
import {
  AfpCreateClubDocumentBody,
  AfpCreateClubDocumentResponse,
  AfpCreateClubPlayerBody,
  AfpCreateClubPlayerResponse,
  AfpCreateClubRegistrationBody,
  AfpCreateClubRegistrationResponse,
  AfpCreateClubTeamBody,
  AfpCreateClubTeamResponse,
  AfpGetClubDashboardResponse,
  AfpGetPlayerAuthOptionsResponse,
  AfpListClubDocumentsResponse,
  AfpListClubPlayersResponse,
  AfpListClubRegistrationsResponse,
  AfpListClubTeamsResponse,
  AfpStartPlayerAuthBody,
  AfpStartPlayerAuthResponse,
} from "@workspace/api-zod";
import { getSessionUser } from "./afp-auth";

const router: IRouter = Router();
const demoClubId = "clube-demonstracao";
const identityFlowCookieName = "afp_player_identity_flow";
const identityFlowTtlMs = 10 * 60 * 1000;

type IdentityMethod = "cmd" | "citizen_card";

type IdentityProviderConfig = {
  method: IdentityMethod;
  label: string;
  authorizationUrl: string;
  tokenUrl: string;
  userInfoUrl: string;
  clientId: string;
  clientSecret?: string;
  redirectUri: string;
  scope: string;
  identityClaim?: string;
};

type IdentityFlow = {
  state: string;
  codeVerifier: string;
  playerId: number;
  method: IdentityMethod;
  expiresAt: number;
};

function getIdentityProviderConfig(method: IdentityMethod): IdentityProviderConfig | null {
  const prefix = method === "cmd" ? "AFP_CMD" : "AFP_CITIZEN_CARD";
  const authorizationUrl = process.env[`${prefix}_AUTHORIZATION_URL`]?.trim();
  const tokenUrl = process.env[`${prefix}_TOKEN_URL`]?.trim();
  const userInfoUrl = process.env[`${prefix}_USERINFO_URL`]?.trim();
  const clientId = process.env[`${prefix}_CLIENT_ID`]?.trim();
  const redirectUri = process.env[`${prefix}_REDIRECT_URI`]?.trim();

  if (!authorizationUrl || !tokenUrl || !userInfoUrl || !clientId || !redirectUri) {
    return null;
  }

  return {
    method,
    label: method === "cmd" ? "Chave Móvel Digital" : "Cartão de Cidadão",
    authorizationUrl,
    tokenUrl,
    userInfoUrl,
    clientId,
    clientSecret: process.env[`${prefix}_CLIENT_SECRET`]?.trim() || undefined,
    redirectUri,
    scope: process.env[`${prefix}_SCOPE`]?.trim() || "openid profile",
    identityClaim: process.env[`${prefix}_IDENTITY_CLAIM`]?.trim() || undefined,
  };
}

function getConfiguredIdentityMethods() {
  return (["cmd", "citizen_card"] as const).filter(
    (method) => getIdentityProviderConfig(method) !== null,
  );
}

function getSessionSecret() {
  const secret = process.env.SESSION_SECRET?.trim();
  if (!secret) {
    throw new Error("SESSION_SECRET is required for player identity authentication.");
  }
  return secret;
}

function encodeBase64Url(value: string) {
  return Buffer.from(value).toString("base64url");
}

function signIdentityFlow(flow: IdentityFlow) {
  const payload = encodeBase64Url(JSON.stringify(flow));
  const signature = createHmac("sha256", getSessionSecret()).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function readSignedIdentityFlow(value: unknown): IdentityFlow | null {
  if (typeof value !== "string") {
    return null;
  }

  const [payload, signature] = value.split(".");
  if (!payload || !signature) {
    return null;
  }

  const expectedSignature = createHmac("sha256", getSessionSecret())
    .update(payload)
    .digest("base64url");
  const received = Buffer.from(signature);
  const expected = Buffer.from(expectedSignature);
  if (received.length !== expected.length || !timingSafeEqual(received, expected)) {
    return null;
  }

  try {
    const flow = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as IdentityFlow;
    if (
      !flow.state ||
      !flow.codeVerifier ||
      !Number.isInteger(flow.playerId) ||
      (flow.method !== "cmd" && flow.method !== "citizen_card") ||
      !Number.isFinite(flow.expiresAt) ||
      flow.expiresAt < Date.now()
    ) {
      return null;
    }
    return flow;
  } catch {
    return null;
  }
}

function identityFlowCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    maxAge: identityFlowTtlMs,
    path: "/",
  };
}

function normalizeIdentifier(value: unknown) {
  if (typeof value !== "string" && typeof value !== "number") {
    return "";
  }
  return String(value).replace(/\D/g, "");
}

function normalizePersonName(value: unknown) {
  if (typeof value !== "string") {
    return "";
  }
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function getClaim(identity: Record<string, unknown>, claim: string) {
  return claim.split(".").reduce<unknown>((value, key) => {
    if (!value || typeof value !== "object") {
      return undefined;
    }
    return (value as Record<string, unknown>)[key];
  }, identity);
}

function firstClaim(identity: Record<string, unknown>, claims: string[]) {
  for (const claim of claims) {
    const value = getClaim(identity, claim);
    if (typeof value === "string" || typeof value === "number") {
      return value;
    }
  }
  return undefined;
}

function validatePlayerIdentity(
  identity: Record<string, unknown>,
  player: typeof afpPlayersTable.$inferSelect,
  provider: IdentityProviderConfig,
) {
  const identityClaims = [
    provider.identityClaim,
    "national_id",
    "nationalId",
    "citizen_card_number",
    "citizenCardNumber",
    "document_number",
    "documentNumber",
    "nif",
    "tax_number",
  ].filter((claim): claim is string => Boolean(claim));
  const claimedIdentifier = normalizeIdentifier(firstClaim(identity, identityClaims));
  const playerIdentifier = normalizeIdentifier(player.nationalId);

  if (!claimedIdentifier || !playerIdentifier || claimedIdentifier !== playerIdentifier) {
    return false;
  }

  const claimedName = firstClaim(identity, ["name", "full_name", "fullName"]);
  if (claimedName && normalizePersonName(claimedName) !== normalizePersonName(player.fullName)) {
    return false;
  }

  const claimedBirthDate = firstClaim(identity, ["birthdate", "birthDate", "date_of_birth"]);
  if (claimedBirthDate && String(claimedBirthDate).slice(0, 10) !== player.birthDate) {
    return false;
  }

  return true;
}

async function readJsonResponse(response: Response) {
  try {
    return (await response.json()) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function authRedirect(req: Request, result: "verified" | "error", code: string) {
  const configured = process.env.AFP_PLAYER_AUTH_FRONTEND_REDIRECT_URI?.trim();
  const redirect = configured || "/afp-barcelos/club/player-auth";
  const url = new URL(redirect, configured ? `${req.protocol}://${req.get("host")}` : "http://relative");
  url.searchParams.set("auth", result);
  url.searchParams.set("code", code);
  return configured ? url.toString() : `${url.pathname}${url.search}`;
}

function parseId(value: string | string[]) {
  return Number(Array.isArray(value) ? value[0] : value);
}

function toDateString(value: Date | string | null | undefined) {
  if (value == null || typeof value === "string") {
    return value;
  }
  return value.toISOString().slice(0, 10);
}

async function requireClub(req: Request) {
  const session = await getSessionUser(req);
  if (!session || session.user.role !== "club") {
    return null;
  }
  return session.user;
}

function playerView(
  player: typeof afpPlayersTable.$inferSelect,
  team?: typeof afpTeamsTable.$inferSelect,
) {
  return {
    ...player,
    teamName: team?.name ?? null,
    nationalId: player.nationalId.replace(/^(.{3}).*(.{2})$/, "$1••••$2"),
  };
}

export async function seedAfpClubDemoData() {
  const existing = await db
    .select({ value: count() })
    .from(afpPlayersTable)
    .where(eq(afpPlayersTable.clubId, demoClubId));
  if (Number(existing[0]?.value ?? 0) > 0) {
    return;
  }

  const [sub17, senior] = await db
    .insert(afpTeamsTable)
    .values([
      {
        clubId: demoClubId,
        name: "Sub-17",
        category: "Formação",
        season: "2025 / 26",
      },
      {
        clubId: demoClubId,
        name: "Seniores",
        category: "Futebol 11",
        season: "2025 / 26",
      },
    ])
    .returning();

  const players = await db
    .insert(afpPlayersTable)
    .values([
      {
        clubId: demoClubId,
        fullName: "Martim Carvalho",
        birthDate: "2010-04-18",
        nationalId: "312456789",
        position: "Avançado",
        teamId: sub17.id,
        status: "active",
        authStatus: "verified",
      },
      {
        clubId: demoClubId,
        fullName: "Diogo Faria",
        birthDate: "2007-11-06",
        nationalId: "298765431",
        position: "Médio",
        teamId: senior.id,
        status: "active",
        authStatus: "pending",
      },
      {
        clubId: demoClubId,
        fullName: "Rafael Lima",
        birthDate: "2011-02-24",
        nationalId: "305432198",
        position: "Defesa",
        teamId: sub17.id,
        status: "draft",
        authStatus: "not_started",
      },
      {
        clubId: demoClubId,
        fullName: "João Mendes",
        birthDate: "2005-08-13",
        nationalId: "287654309",
        position: "Guarda-redes",
        teamId: senior.id,
        status: "active",
        authStatus: "verified",
      },
    ])
    .returning();

  await db.insert(afpDocumentsTable).values([
    {
      clubId: demoClubId,
      playerId: players[0].id,
      type: "Cartão de cidadão",
      fileName: "martim-carvalho-cc.pdf",
      status: "valid",
      expiresAt: "2030-04-18",
    },
    {
      clubId: demoClubId,
      playerId: players[1].id,
      type: "Atestado médico",
      fileName: "diogo-faria-atestado.pdf",
      status: "pending",
      expiresAt: "2026-09-30",
    },
    {
      clubId: demoClubId,
      playerId: players[2].id,
      type: "Autorização parental",
      fileName: "pendente de carregamento",
      status: "pending",
    },
  ]);

  await db.insert(afpRegistrationsTable).values([
    {
      clubId: demoClubId,
      playerId: players[0].id,
      teamId: sub17.id,
      competition: "Campeonato Popular",
      category: "Sub-17",
      status: "approved",
      authMethod: "citizen_card",
    },
    {
      clubId: demoClubId,
      playerId: players[1].id,
      teamId: senior.id,
      competition: "Taça Cidade de Barcelos",
      category: "Seniores",
      status: "under_review",
      authMethod: "cmd",
    },
    {
      clubId: demoClubId,
      playerId: players[2].id,
      teamId: sub17.id,
      competition: "Campeonato Popular",
      category: "Sub-17",
      status: "needs_attention",
      authMethod: "manual",
    },
  ]);
}

router.use("/afp/club", async (req, res, next) => {
  const user = await requireClub(req);
  if (!user) {
    res.status(403).json({ error: "Esta área está disponível apenas para clubes." });
    return;
  }
  next();
});

router.get("/afp/club/dashboard", async (_req, res): Promise<void> => {
  const [players, teams, documents, registrations] = await Promise.all([
    db.select().from(afpPlayersTable).where(eq(afpPlayersTable.clubId, demoClubId)),
    db.select().from(afpTeamsTable).where(eq(afpTeamsTable.clubId, demoClubId)),
    db
      .select()
      .from(afpDocumentsTable)
      .where(eq(afpDocumentsTable.clubId, demoClubId)),
    db
      .select()
      .from(afpRegistrationsTable)
      .where(eq(afpRegistrationsTable.clubId, demoClubId)),
  ]);
  const pendingDocuments = documents.filter((item) => item.status !== "valid").length;
  const pendingRegistrations = registrations.filter(
    (item) => !["approved"].includes(item.status),
  ).length;
  const verifiedPlayers = players.filter((item) => item.authStatus === "verified").length;

  res.json(
    AfpGetClubDashboardResponse.parse({
      club: {
        id: demoClubId,
        name: "Clube de Demonstração",
        season: "2025 / 26",
      },
      metrics: {
        playerCount: players.length,
        teamCount: teams.length,
        pendingDocuments,
        pendingRegistrations,
        verifiedPlayers,
      },
      attention: [
        ...(pendingDocuments > 0
          ? [
              {
                kind: "documents",
                label: "Documentos pendentes",
                count: pendingDocuments,
                tone: "amber",
              },
            ]
          : []),
        ...(pendingRegistrations > 0
          ? [
              {
                kind: "registrations",
                label: "Inscrições em acompanhamento",
                count: pendingRegistrations,
                tone: "blue",
              },
            ]
          : []),
      ],
    }),
  );
});

router.get("/afp/club/players", async (_req, res): Promise<void> => {
  const [players, teams] = await Promise.all([
    db
      .select()
      .from(afpPlayersTable)
      .where(eq(afpPlayersTable.clubId, demoClubId))
      .orderBy(asc(afpPlayersTable.fullName)),
    db.select().from(afpTeamsTable).where(eq(afpTeamsTable.clubId, demoClubId)),
  ]);
  const teamMap = new Map(teams.map((team) => [team.id, team]));
  res.json(
    AfpListClubPlayersResponse.parse(
      players.map((player) => playerView(player, player.teamId ? teamMap.get(player.teamId) : undefined)),
    ),
  );
});

router.post("/afp/club/players", async (req, res): Promise<void> => {
  const parsed = AfpCreateClubPlayerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Confirme os dados obrigatórios do jogador." });
    return;
  }
  const [player] = await db
    .insert(afpPlayersTable)
    .values({
      ...parsed.data,
      clubId: demoClubId,
      birthDate: toDateString(parsed.data.birthDate) as string,
    })
    .returning();
  const [team] = parsed.data.teamId
    ? await db.select().from(afpTeamsTable).where(eq(afpTeamsTable.id, parsed.data.teamId))
    : [];
  res.status(201).json(AfpCreateClubPlayerResponse.parse(playerView(player, team)));
});

router.get("/afp/club/teams", async (_req, res): Promise<void> => {
  const teams = await db
    .select({
      id: afpTeamsTable.id,
      clubId: afpTeamsTable.clubId,
      name: afpTeamsTable.name,
      category: afpTeamsTable.category,
      season: afpTeamsTable.season,
      status: afpTeamsTable.status,
      createdAt: afpTeamsTable.createdAt,
      playerCount: count(afpPlayersTable.id),
    })
    .from(afpTeamsTable)
    .leftJoin(afpPlayersTable, eq(afpPlayersTable.teamId, afpTeamsTable.id))
    .where(eq(afpTeamsTable.clubId, demoClubId))
    .groupBy(afpTeamsTable.id)
    .orderBy(asc(afpTeamsTable.name));
  res.json(
    AfpListClubTeamsResponse.parse(
      teams.map((team) => ({ ...team, playerCount: Number(team.playerCount) })),
    ),
  );
});

router.post("/afp/club/teams", async (req, res): Promise<void> => {
  const parsed = AfpCreateClubTeamBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Indique o nome, categoria e época da equipa." });
    return;
  }
  const [team] = await db
    .insert(afpTeamsTable)
    .values({ ...parsed.data, clubId: demoClubId })
    .returning();
  res.status(201).json(AfpCreateClubTeamResponse.parse({ ...team, playerCount: 0 }));
});

router.get("/afp/club/documents", async (_req, res): Promise<void> => {
  const [documents, players] = await Promise.all([
    db.select().from(afpDocumentsTable).where(eq(afpDocumentsTable.clubId, demoClubId)),
    db.select().from(afpPlayersTable).where(eq(afpPlayersTable.clubId, demoClubId)),
  ]);
  const playerMap = new Map(players.map((player) => [player.id, player.fullName]));
  res.json(
    AfpListClubDocumentsResponse.parse(
      documents.map((document) => ({
        ...document,
        playerName: document.playerId ? playerMap.get(document.playerId) ?? null : null,
      })),
    ),
  );
});

router.post("/afp/club/documents", async (req, res): Promise<void> => {
  const parsed = AfpCreateClubDocumentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Indique o jogador, tipo e nome do documento." });
    return;
  }
  const [document] = await db
    .insert(afpDocumentsTable)
    .values({
      ...parsed.data,
      clubId: demoClubId,
      expiresAt: toDateString(parsed.data.expiresAt),
    })
    .returning();
  const [player] = await db
    .select()
    .from(afpPlayersTable)
    .where(eq(afpPlayersTable.id, parsed.data.playerId));
  res
    .status(201)
    .json(
      AfpCreateClubDocumentResponse.parse({
        ...document,
        playerName: player?.fullName ?? null,
      }),
    );
});

router.get("/afp/club/registrations", async (_req, res): Promise<void> => {
  const [registrations, players, teams] = await Promise.all([
    db
      .select()
      .from(afpRegistrationsTable)
      .where(eq(afpRegistrationsTable.clubId, demoClubId))
      .orderBy(asc(afpRegistrationsTable.createdAt)),
    db.select().from(afpPlayersTable).where(eq(afpPlayersTable.clubId, demoClubId)),
    db.select().from(afpTeamsTable).where(eq(afpTeamsTable.clubId, demoClubId)),
  ]);
  const playerMap = new Map(players.map((player) => [player.id, player.fullName]));
  const teamMap = new Map(teams.map((team) => [team.id, team.name]));
  res.json(
    AfpListClubRegistrationsResponse.parse(
      registrations.map((registration) => ({
        ...registration,
        playerName: playerMap.get(registration.playerId) ?? "Jogador",
        teamName: registration.teamId ? teamMap.get(registration.teamId) ?? null : null,
      })),
    ),
  );
});

router.post("/afp/club/registrations", async (req, res): Promise<void> => {
  const parsed = AfpCreateClubRegistrationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Complete os dados da inscrição." });
    return;
  }
  const [registration] = await db
    .insert(afpRegistrationsTable)
    .values({ ...parsed.data, clubId: demoClubId })
    .returning();
  const [player] = await db
    .select()
    .from(afpPlayersTable)
    .where(eq(afpPlayersTable.id, parsed.data.playerId));
  const [team] = parsed.data.teamId
    ? await db.select().from(afpTeamsTable).where(eq(afpTeamsTable.id, parsed.data.teamId))
    : [];
  res
    .status(201)
    .json(
      AfpCreateClubRegistrationResponse.parse({
        ...registration,
        playerName: player?.fullName ?? "Jogador",
        teamName: team?.name ?? null,
      }),
    );
});

router.get("/afp/club/player-auth/options", async (_req, res): Promise<void> => {
  const configuredMethods = getConfiguredIdentityMethods();
  res.json(
    AfpGetPlayerAuthOptionsResponse.parse({
      method: null,
      status: configuredMethods.length > 0 ? "ready" : "provider_configuration_required",
      message:
        configuredMethods.length > 0
          ? "Os fornecedores oficiais de identidade estão disponíveis."
          : "A AFP ainda precisa configurar pelo menos um fornecedor oficial CMD ou Cartão de Cidadão.",
      authorizationUrl: null,
    }),
  );
});

router.post("/afp/club/player-auth/start", async (req, res): Promise<void> => {
  const parsed = AfpStartPlayerAuthBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Selecione o jogador e o método de autenticação." });
    return;
  }

  if (parsed.data.method === "manual") {
    await db
      .update(afpPlayersTable)
      .set({ authStatus: "pending" })
      .where(
        and(eq(afpPlayersTable.id, parsed.data.playerId), eq(afpPlayersTable.clubId, demoClubId)),
      );
    res.json(
      AfpStartPlayerAuthResponse.parse({
        method: parsed.data.method,
        status: "pending",
        message: "O pedido foi registado para validação manual pela AFP.",
        authorizationUrl: null,
      }),
    );
    return;
  }

  const provider = getIdentityProviderConfig(parsed.data.method);
  const [player] = await db
    .select()
    .from(afpPlayersTable)
    .where(
      and(eq(afpPlayersTable.id, parsed.data.playerId), eq(afpPlayersTable.clubId, demoClubId)),
    )
    .limit(1);

  if (!player) {
    res.status(404).json({ error: "O jogador selecionado não existe neste clube." });
    return;
  }

  if (!provider) {
    res.json(
      AfpStartPlayerAuthResponse.parse({
        method: parsed.data.method,
        status: "provider_configuration_required",
        message:
          parsed.data.method === "cmd"
            ? "A ligação à Chave Móvel Digital ainda precisa de configuração oficial."
            : "A ligação ao Cartão de Cidadão ainda precisa de configuração oficial.",
        authorizationUrl: null,
      }),
    );
    return;
  }

  const state = randomBytes(32).toString("base64url");
  const codeVerifier = randomBytes(32).toString("base64url");
  const flow: IdentityFlow = {
    state,
    codeVerifier,
    playerId: player.id,
    method: parsed.data.method,
    expiresAt: Date.now() + identityFlowTtlMs,
  };
  const codeChallenge = createHash("sha256").update(codeVerifier).digest("base64url");
  const authorizationUrl = new URL(provider.authorizationUrl);
  authorizationUrl.searchParams.set("response_type", "code");
  authorizationUrl.searchParams.set("client_id", provider.clientId);
  authorizationUrl.searchParams.set("redirect_uri", provider.redirectUri);
  authorizationUrl.searchParams.set("scope", provider.scope);
  authorizationUrl.searchParams.set("state", state);
  authorizationUrl.searchParams.set("code_challenge", codeChallenge);
  authorizationUrl.searchParams.set("code_challenge_method", "S256");

  await db
    .update(afpPlayersTable)
    .set({ authStatus: "pending" })
    .where(eq(afpPlayersTable.id, player.id));
  res.cookie(identityFlowCookieName, signIdentityFlow(flow), identityFlowCookieOptions());
  res.json(
    AfpStartPlayerAuthResponse.parse({
      method: parsed.data.method,
      status: "ready",
      message: `A iniciar autenticação com ${provider.label}.`,
      authorizationUrl: authorizationUrl.toString(),
    }),
  );
});

router.get(
  "/afp/club/player-auth/callback/:method",
  async (req, res): Promise<void> => {
    const method = req.params.method;
    const provider =
      method === "cmd" || method === "citizen_card"
        ? getIdentityProviderConfig(method)
        : null;
    const flow = readSignedIdentityFlow(req.cookies?.[identityFlowCookieName]);
    const clearFlowCookie = () => res.clearCookie(identityFlowCookieName, identityFlowCookieOptions());

    if (!provider || !flow || flow.method !== method) {
      clearFlowCookie();
      res.redirect(authRedirect(req, "error", "invalid_state"));
      return;
    }

    if (typeof req.query.error === "string") {
      clearFlowCookie();
      res.redirect(authRedirect(req, "error", "provider_denied"));
      return;
    }

    const code = typeof req.query.code === "string" ? req.query.code : "";
    const state = typeof req.query.state === "string" ? req.query.state : "";
    if (!code || !state || state !== flow.state) {
      clearFlowCookie();
      res.redirect(authRedirect(req, "error", "invalid_state"));
      return;
    }

    try {
      const tokenBody = new URLSearchParams({
        grant_type: "authorization_code",
        code,
        client_id: provider.clientId,
        redirect_uri: provider.redirectUri,
        code_verifier: flow.codeVerifier,
      });
      if (provider.clientSecret) {
        tokenBody.set("client_secret", provider.clientSecret);
      }

      const tokenResponse = await fetch(provider.tokenUrl, {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded", accept: "application/json" },
        body: tokenBody,
        signal: AbortSignal.timeout(10000),
      });
      const token = await readJsonResponse(tokenResponse);
      const accessToken = token?.access_token;
      if (!tokenResponse.ok || typeof accessToken !== "string" || !accessToken) {
        throw new Error("Identity provider token exchange failed.");
      }

      const identityResponse = await fetch(provider.userInfoUrl, {
        headers: { authorization: `Bearer ${accessToken}`, accept: "application/json" },
        signal: AbortSignal.timeout(10000),
      });
      const identity = await readJsonResponse(identityResponse);
      if (!identityResponse.ok || !identity || typeof identity !== "object") {
        throw new Error("Identity provider user info request failed.");
      }

      const [player] = await db
        .select()
        .from(afpPlayersTable)
        .where(
          and(eq(afpPlayersTable.id, flow.playerId), eq(afpPlayersTable.clubId, demoClubId)),
        )
        .limit(1);
      if (!player || !validatePlayerIdentity(identity, player, provider)) {
        clearFlowCookie();
        res.redirect(authRedirect(req, "error", "identity_mismatch"));
        return;
      }

      await db
        .update(afpPlayersTable)
        .set({ authStatus: "verified" })
        .where(
          and(eq(afpPlayersTable.id, player.id), eq(afpPlayersTable.clubId, demoClubId)),
        );
      clearFlowCookie();
      res.redirect(authRedirect(req, "verified", "identity_verified"));
    } catch (error) {
      req.log.error({ err: error, method }, "Player identity provider callback failed");
      clearFlowCookie();
      res.redirect(authRedirect(req, "error", "provider_unavailable"));
    }
  },
);

export default router;