import { Readable } from "node:stream";
import { Router, type IRouter, type Request } from "express";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db, afpPlayersTable, afpRegistrationDocumentsTable, afpRegistrationsTable, afpTeamsTable } from "@workspace/db";
import {
  AfpCreateClubRegistrationDocumentBody,
  AfpCreateClubRegistrationDocumentResponse,
  AfpListBoardRegistrationDocumentsResponse,
  AfpListBoardRegistrationsResponse,
  AfpListClubRegistrationDocumentsResponse,
  AfpRequestRegistrationDocumentUploadUrlBody,
  AfpRequestRegistrationDocumentUploadUrlResponse,
  AfpReviewRegistrationDocumentBody,
  AfpReviewRegistrationDocumentResponse,
} from "@workspace/api-zod";
import { getSessionUser } from "./afp-auth";
import { ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const storage = new ObjectStorageService();

async function sessionWithRole(req: Request, role: "club" | "board") {
  const session = await getSessionUser(req);
  return session?.user.role === role ? session : null;
}

async function registrationForClub(id: number, clubId: string) {
  const [registration] = await db.select().from(afpRegistrationsTable).where(and(eq(afpRegistrationsTable.id, id), eq(afpRegistrationsTable.clubId, clubId))).limit(1);
  return registration;
}

function documentView(document: typeof afpRegistrationDocumentsTable.$inferSelect) {
  return { id: document.id, registrationId: document.registrationId, documentType: document.documentType, fileName: document.fileName, contentType: document.contentType, objectPath: document.objectPath, status: document.status, reviewNote: document.reviewNote, reviewedAt: document.reviewedAt, createdAt: document.createdAt };
}

router.use("/afp/registration-documents/:documentId/file", async (req, res, next) => {
  const session = await getSessionUser(req);
  if (!session || !["club", "board"].includes(session.user.role)) { res.status(403).json({ error: "Acesso reservado à AFP." }); return; }
  const documentId = Number(req.params.documentId);
  const [document] = await db.select().from(afpRegistrationDocumentsTable).where(eq(afpRegistrationDocumentsTable.id, documentId)).limit(1);
  if (!document) { res.status(404).json({ error: "Documento não encontrado." }); return; }
  const registration = await db.select().from(afpRegistrationsTable).where(eq(afpRegistrationsTable.id, document.registrationId)).limit(1);
  if (session.user.role === "club" && registration[0]?.clubId !== "clube-demonstracao") { res.status(403).json({ error: "Documento não pertence ao clube." }); return; }
  try {
    const file = await storage.getFile(document.objectPath);
    const [metadata] = await file.getMetadata();
    res.setHeader("Content-Type", metadata.contentType || document.contentType);
    res.setHeader("Content-Disposition", `inline; filename="${document.fileName.replace(/["\r\n]/g, "")}"`);
    Readable.from(file.createReadStream()).pipe(res);
  } catch { res.status(404).json({ error: "Ficheiro não encontrado." }); }
  void next;
});

router.post("/afp/club/registration-documents/upload-url", async (req, res): Promise<void> => {
  const session = await sessionWithRole(req, "club");
  if (!session) { res.status(403).json({ error: "Esta área está disponível apenas para clubes." }); return; }
  const parsed = AfpRequestRegistrationDocumentUploadUrlBody.safeParse(req.body);
  if (!parsed.success || !(await registrationForClub(parsed.data.registrationId, "clube-demonstracao"))) { res.status(400).json({ error: "Inscrição inválida para este clube." }); return; }
  try { res.json(AfpRequestRegistrationDocumentUploadUrlResponse.parse(await storage.requestUploadUrl())); } catch { res.status(500).json({ error: "Não foi possível preparar o carregamento." }); }
});

router.get("/afp/club/registrations/:registrationId/documents", async (req, res): Promise<void> => {
  const session = await sessionWithRole(req, "club");
  const registrationId = Number(req.params.registrationId);
  if (!session || !(await registrationForClub(registrationId, "clube-demonstracao"))) { res.status(403).json({ error: "Inscrição indisponível." }); return; }
  const documents = await db.select().from(afpRegistrationDocumentsTable).where(eq(afpRegistrationDocumentsTable.registrationId, registrationId)).orderBy(asc(afpRegistrationDocumentsTable.createdAt));
  res.json(AfpListClubRegistrationDocumentsResponse.parse(documents.map(documentView)));
});

router.post("/afp/club/registrations/:registrationId/documents", async (req, res): Promise<void> => {
  const session = await sessionWithRole(req, "club");
  const registrationId = Number(req.params.registrationId);
  const registration = session ? await registrationForClub(registrationId, "clube-demonstracao") : null;
  const parsed = AfpCreateClubRegistrationDocumentBody.safeParse(req.body);
  if (!session || !registration || !parsed.success || !parsed.data.objectPath.startsWith("/objects/")) { res.status(400).json({ error: "Indique um documento carregado e válido." }); return; }
  const [document] = await db.insert(afpRegistrationDocumentsTable).values({ registrationId, clubId: "clube-demonstracao", ...parsed.data }).returning();
  await db.update(afpRegistrationsTable).set({ status: "under_review" }).where(eq(afpRegistrationsTable.id, registrationId));
  res.status(201).json(AfpCreateClubRegistrationDocumentResponse.parse(documentView(document)));
});

router.get("/afp/board/registrations", async (req, res): Promise<void> => {
  if (!(await sessionWithRole(req, "board"))) { res.status(403).json({ error: "Esta área está disponível apenas para a direção." }); return; }
  const [registrations, players, teams, documents] = await Promise.all([
    db.select().from(afpRegistrationsTable).orderBy(asc(afpRegistrationsTable.createdAt)),
    db.select().from(afpPlayersTable),
    db.select().from(afpTeamsTable),
    db.select().from(afpRegistrationDocumentsTable),
  ]);
  const playerMap = new Map(players.map((item) => [item.id, item.fullName]));
  const teamMap = new Map(teams.map((item) => [item.id, item.name]));
  res.json(AfpListBoardRegistrationsResponse.parse(registrations.map((item) => {
    const related = documents.filter((document) => document.registrationId === item.id);
    return { ...item, playerName: playerMap.get(item.playerId) ?? "Jogador", teamName: item.teamId ? teamMap.get(item.teamId) ?? null : null, documentCount: related.length, pendingDocumentCount: related.filter((document) => document.status === "pending").length, rejectedDocumentCount: related.filter((document) => document.status === "rejected").length };
  })));
});

router.get("/afp/board/registrations/:registrationId/documents", async (req, res): Promise<void> => {
  if (!(await sessionWithRole(req, "board"))) { res.status(403).json({ error: "Acesso reservado à direção." }); return; }
  const documents = await db.select().from(afpRegistrationDocumentsTable).where(eq(afpRegistrationDocumentsTable.registrationId, Number(req.params.registrationId)));
  res.json(AfpListBoardRegistrationDocumentsResponse.parse(documents.map(documentView)));
});

router.patch("/afp/board/registration-documents/:documentId/review", async (req, res): Promise<void> => {
  const session = await sessionWithRole(req, "board");
  const parsed = AfpReviewRegistrationDocumentBody.safeParse(req.body);
  const documentId = Number(req.params.documentId);
  if (!session || !parsed.success || (parsed.data.status === "rejected" && !parsed.data.reviewNote?.trim())) { res.status(400).json({ error: "A rejeição exige uma justificação." }); return; }
  const [document] = await db.update(afpRegistrationDocumentsTable).set({ status: parsed.data.status, reviewNote: parsed.data.status === "approved" ? null : parsed.data.reviewNote?.trim() ?? null, reviewedBy: session.user.id, reviewedAt: new Date() }).where(eq(afpRegistrationDocumentsTable.id, documentId)).returning();
  if (!document) { res.status(404).json({ error: "Documento não encontrado." }); return; }
  const documents = await db.select().from(afpRegistrationDocumentsTable).where(eq(afpRegistrationDocumentsTable.registrationId, document.registrationId));
  const nextStatus = documents.some((item) => item.status === "rejected") ? "needs_attention" : documents.length > 0 && documents.every((item) => item.status === "approved") ? "approved" : "under_review";
  await db.update(afpRegistrationsTable).set({ status: nextStatus }).where(eq(afpRegistrationsTable.id, document.registrationId));
  res.json(AfpReviewRegistrationDocumentResponse.parse(documentView(document)));
});

export default router;