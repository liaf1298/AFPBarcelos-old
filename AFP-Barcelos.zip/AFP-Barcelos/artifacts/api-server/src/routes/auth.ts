import { promisify } from "node:util";
import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { Router, type IRouter, type Request } from "express";
import { and, count, eq, gt, lt } from "drizzle-orm";
import { db, demoSessionsTable, demoUsersTable } from "@workspace/db";
import {
  GetAuthStatusResponse,
  GetCurrentUserResponse,
  LoginBody,
  LoginResponse,
  RegisterBody,
  RegisterResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const sessionCookieName = "login_tester_session";
const sessionDurationMinutes = 60 * 24 * 7;
const sessionDurationMs = sessionDurationMinutes * 60 * 1000;
const scrypt = promisify(scryptCallback);

function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    maxAge: sessionDurationMs,
    path: "/",
  };
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

async function hashPassword(password: string, salt = randomBytes(16).toString("hex")) {
  const derivedKey = (await scrypt(password, salt, 64)) as Buffer;
  return { hash: derivedKey.toString("hex"), salt };
}

async function passwordMatches(password: string, hash: string, salt: string) {
  const candidate = (await scrypt(password, salt, 64)) as Buffer;
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

async function createSession(userId: number) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + sessionDurationMs);

  await db.insert(demoSessionsTable).values({
    userId,
    tokenHash: hashToken(token),
    expiresAt,
  });

  return { token, expiresAt };
}

async function getSessionUser(req: Request) {
  const token = req.cookies?.[sessionCookieName];
  if (typeof token !== "string" || token.length === 0) {
    return null;
  }

  const rows = await db
    .select({
      session: demoSessionsTable,
      user: demoUsersTable,
    })
    .from(demoSessionsTable)
    .innerJoin(demoUsersTable, eq(demoSessionsTable.userId, demoUsersTable.id))
    .where(
      and(
        eq(demoSessionsTable.tokenHash, hashToken(token)),
        gt(demoSessionsTable.expiresAt, new Date()),
      ),
    )
    .limit(1);

  return rows[0] ?? null;
}

function userResponse(user: typeof demoUsersTable.$inferSelect, signedInAt: Date) {
  return {
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      createdAt: user.createdAt,
    },
    signedInAt,
  };
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.flatten() }, "Invalid registration body");
    res.status(400).json({ error: "Indica um nome, email e palavra-passe válida." });
    return;
  }

  const name = parsed.data.name.trim();
  const email = parsed.data.email.trim().toLowerCase();
  const existing = await db
    .select({ id: demoUsersTable.id })
    .from(demoUsersTable)
    .where(eq(demoUsersTable.email, email))
    .limit(1);

  if (existing.length > 0) {
    res.status(409).json({ error: "Já existe uma conta com este email." });
    return;
  }

  const password = await hashPassword(parsed.data.password);
  const [user] = await db
    .insert(demoUsersTable)
    .values({
      name,
      email,
      passwordHash: password.hash,
      passwordSalt: password.salt,
    })
    .returning();

  const session = await createSession(user.id);
  res.cookie(sessionCookieName, session.token, cookieOptions());
  res.status(201).json(RegisterResponse.parse(userResponse(user, new Date())));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Indica um email e uma palavra-passe." });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const [user] = await db
    .select()
    .from(demoUsersTable)
    .where(eq(demoUsersTable.email, email))
    .limit(1);

  if (!user || !(await passwordMatches(parsed.data.password, user.passwordHash, user.passwordSalt))) {
    req.log.info({ email }, "Rejected login attempt");
    res.status(401).json({ error: "Email ou palavra-passe incorretos." });
    return;
  }

  const session = await createSession(user.id);
  res.cookie(sessionCookieName, session.token, cookieOptions());
  res.json(LoginResponse.parse(userResponse(user, new Date())));
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const session = await getSessionUser(req);
  if (!session) {
    res.status(401).json({ error: "Não existe uma sessão ativa." });
    return;
  }

  res.json(
    GetCurrentUserResponse.parse(
      userResponse(session.user, session.session.createdAt),
    ),
  );
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const token = req.cookies?.[sessionCookieName];
  if (typeof token === "string" && token.length > 0) {
    await db
      .delete(demoSessionsTable)
      .where(eq(demoSessionsTable.tokenHash, hashToken(token)));
  }

  res.clearCookie(sessionCookieName, cookieOptions());
  res.sendStatus(204);
});

router.get("/auth/status", async (_req, res): Promise<void> => {
  const now = new Date();
  await db
    .delete(demoSessionsTable)
    .where(lt(demoSessionsTable.expiresAt, now));

  const [accounts, activeSessions] = await Promise.all([
    db.select({ value: count() }).from(demoUsersTable),
    db
      .select({ value: count() })
      .from(demoSessionsTable)
      .where(gt(demoSessionsTable.expiresAt, now)),
  ]);

  res.json(
    GetAuthStatusResponse.parse({
      accountCount: Number(accounts[0]?.value ?? 0),
      activeSessionCount: Number(activeSessions[0]?.value ?? 0),
      sessionDurationMinutes,
    }),
  );
});

export default router;