import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import afpAuthRouter from "./afp-auth";
import afpClubRouter from "./afp-club";
import afpRegistrationRouter from "./afp-registration";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(afpAuthRouter);
router.use(afpClubRouter);
router.use(afpRegistrationRouter);

export default router;
