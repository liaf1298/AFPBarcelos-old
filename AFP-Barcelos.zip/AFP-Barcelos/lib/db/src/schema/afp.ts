import { createInsertSchema } from "drizzle-zod";
import {
  date,
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const afpRoleEnum = pgEnum("afp_role", [
  "club",
  "referee",
  "observer",
  "board",
]);

export const afpUsersTable = pgTable("afp_users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  role: afpRoleEnum("role").notNull(),
  affiliation: text("affiliation").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const afpSessionsTable = pgTable("afp_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => afpUsersTable.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const afpPlayerStatusEnum = pgEnum("afp_player_status", [
  "active",
  "draft",
  "inactive",
]);

export const afpPlayerAuthStatusEnum = pgEnum("afp_player_auth_status", [
  "not_started",
  "pending",
  "verified",
]);

export const afpDocumentStatusEnum = pgEnum("afp_document_status", [
  "valid",
  "pending",
  "expired",
]);

export const afpRegistrationStatusEnum = pgEnum("afp_registration_status", [
  "draft",
  "submitted",
  "under_review",
  "approved",
  "needs_attention",
]);

export const afpPlayerAuthMethodEnum = pgEnum("afp_player_auth_method", [
  "cmd",
  "citizen_card",
  "manual",
]);

export const afpRegistrationDocumentStatusEnum = pgEnum("afp_registration_document_status", [
  "pending",
  "approved",
  "rejected",
]);

export const afpTeamsTable = pgTable("afp_teams", {
  id: serial("id").primaryKey(),
  clubId: text("club_id").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  season: text("season").notNull(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const afpPlayersTable = pgTable("afp_players", {
  id: serial("id").primaryKey(),
  clubId: text("club_id").notNull(),
  fullName: text("full_name").notNull(),
  birthDate: date("birth_date", { mode: "string" }).notNull(),
  nationalId: text("national_id").notNull(),
  position: text("position").notNull(),
  teamId: integer("team_id").references(() => afpTeamsTable.id, {
    onDelete: "set null",
  }),
  status: afpPlayerStatusEnum("status").notNull().default("draft"),
  authStatus: afpPlayerAuthStatusEnum("auth_status")
    .notNull()
    .default("not_started"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const afpDocumentsTable = pgTable("afp_documents", {
  id: serial("id").primaryKey(),
  clubId: text("club_id").notNull(),
  playerId: integer("player_id").references(() => afpPlayersTable.id, {
    onDelete: "cascade",
  }),
  type: text("type").notNull(),
  fileName: text("file_name").notNull(),
  status: afpDocumentStatusEnum("status").notNull().default("pending"),
  expiresAt: date("expires_at", { mode: "string" }),
  objectPath: text("object_path"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const afpRegistrationsTable = pgTable("afp_registrations", {
  id: serial("id").primaryKey(),
  clubId: text("club_id").notNull(),
  playerId: integer("player_id")
    .notNull()
    .references(() => afpPlayersTable.id, { onDelete: "cascade" }),
  teamId: integer("team_id").references(() => afpTeamsTable.id, {
    onDelete: "set null",
  }),
  competition: text("competition").notNull(),
  category: text("category").notNull(),
  status: afpRegistrationStatusEnum("status").notNull().default("draft"),
  authMethod: afpPlayerAuthMethodEnum("auth_method").notNull().default("manual"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const afpRegistrationDocumentsTable = pgTable("afp_registration_documents", {
  id: serial("id").primaryKey(),
  registrationId: integer("registration_id")
    .notNull()
    .references(() => afpRegistrationsTable.id, { onDelete: "cascade" }),
  clubId: text("club_id").notNull(),
  documentType: text("document_type").notNull(),
  fileName: text("file_name").notNull(),
  contentType: text("content_type").notNull().default("application/octet-stream"),
  objectPath: text("object_path").notNull(),
  status: afpRegistrationDocumentStatusEnum("status").notNull().default("pending"),
  reviewNote: text("review_note"),
  reviewedBy: integer("reviewed_by").references(() => afpUsersTable.id, { onDelete: "set null" }),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAfpUserSchema = createInsertSchema(afpUsersTable).omit({
  id: true,
  createdAt: true,
});

export type InsertAfpUser = z.infer<typeof insertAfpUserSchema>;
export type AfpUser = typeof afpUsersTable.$inferSelect;
export type AfpSession = typeof afpSessionsTable.$inferSelect;
export type AfpTeam = typeof afpTeamsTable.$inferSelect;
export type AfpPlayer = typeof afpPlayersTable.$inferSelect;
export type AfpDocument = typeof afpDocumentsTable.$inferSelect;
export type AfpRegistration = typeof afpRegistrationsTable.$inferSelect;
export type AfpRegistrationDocument = typeof afpRegistrationDocumentsTable.$inferSelect;